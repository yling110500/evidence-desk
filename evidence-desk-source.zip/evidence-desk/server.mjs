import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {handleApi} from './src/api.mjs';
import {buildClient} from './scripts/build-client.mjs';
const built=await buildClient({outDir:new URL('./dist/client/',import.meta.url).pathname});
const assets=new Set(built.files),types={html:'text/html',js:'text/javascript',mjs:'text/javascript',css:'text/css'};
const port=Number(process.env.PORT||4317),host=process.env.HOST||'127.0.0.1';
const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);let response;
  if(url.pathname.startsWith('/api/'))response=await handleApi(new Request(url,{method:req.method,headers:req.headers,...(['GET','HEAD'].includes(req.method)?{}:{body:req,duplex:'half'})}),process.env);
  else {const name=url.pathname==='/'?'index.html':url.pathname.slice(1);if(assets.has(name)&&['GET','HEAD'].includes(req.method))response=new Response(await readFile(resolve(built.directory,name)),{headers:{'content-type':`${types[name.split('.').at(-1)]||'application/octet-stream'}; charset=utf-8`,'X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','Cache-Control':'no-cache'}});else response=new Response('Not found',{status:404});}
  res.writeHead(response.status,Object.fromEntries(response.headers));res.end(req.method==='HEAD'?undefined:Buffer.from(await response.arrayBuffer()));
 }catch{res.writeHead(500,{'content-type':'application/json'});res.end(JSON.stringify({error:'请求处理失败。'}));}
});
server.listen(port,host,()=>console.log(`Evidence Desk: http://${host}:${port}`));
