import {AppError} from './core.mjs';
export function publicWebUrl(value){
 let u;try{u=new URL(value);}catch{throw new AppError('网页地址无效。');}
 const host=u.hostname.toLowerCase().replace(/^\[|\]$/g,'');
 if(u.protocol!=='https:'||u.username||u.password||u.port&&u.port!=='443'||!host.includes('.')||/^(localhost|127\.|10\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(host)||host.includes(':')||/\.(local|internal|localhost)$/.test(host))throw new AppError('仅支持公开HTTPS网页，不支持内网或含凭证的地址。');
 return u.href;
}
async function webCall(kind,input,env,transport){
 if(!env.LLM_API_KEY)throw new AppError('尚未配置联网搜索服务。',503);
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),25000);
 try{const r=await transport(`https://api.deepseek.com/v1/tools/${kind}`,{method:'POST',headers:{Authorization:`Bearer ${env.LLM_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify(input),signal:controller.signal});if(!r.ok)throw new AppError(r.status===402?'搜索服务余额不足。':r.status===429?'搜索服务繁忙，请稍后重试。':'搜索或正文获取失败，请检查服务权限或换一个来源。',502);const text=await r.text();if(text.length>3000000)throw new AppError('网页响应过大，请选择其他来源。',502);try{return JSON.parse(text);}catch{throw new AppError('搜索服务返回内容无效。',502);}}catch(e){if(e instanceof AppError)throw e;throw new AppError(controller.signal.aborted?'网页检索超时，请重试。':'暂时无法连接网页检索服务。',502);}finally{clearTimeout(timer);}
}
function publicationDate(value){if(typeof value!=='string')return null;const d=value.slice(0,10);return /^\d{4}-\d{2}-\d{2}$/.test(d)&&Number.isFinite(Date.parse(d))&&new Date(d).toISOString().slice(0,10)===d?d:null;}
export async function searchWeb({query,count=5},env,transport=fetch){
 if(typeof query!=='string'||!query.trim()||Array.from(query).length>128)throw new AppError('搜索词须为1—128字。');
 const body=await webCall('search',{query:query.trim(),count:Math.min(5,Math.max(1,Math.floor(count)||5)),need_content:true},env,transport);if(!Array.isArray(body.results))throw new AppError('搜索结果结构不合法。',502);
 return body.results.slice(0,5).flatMap(r=>{let url;try{url=publicWebUrl(r.url);}catch{return [];}const text=typeof r.content==='string'?r.content:'';return [{id:crypto.randomUUID(),url,title:String(r.title||url).slice(0,300),publisher:String(r.site_name||new URL(url).hostname),publishedAt:publicationDate(r.date),retrievedAt:new Date().toISOString(),text,hasFullText:!!text.trim(),snippet:String(r.snippet||''),rankingScore:typeof r.rerank_score==='number'?r.rerank_score:null,authorityTier:r.authority??null,origin:'web'}];});
}
export async function fetchWebPage({url},env,transport=fetch){const safe=publicWebUrl(url),r=await webCall('fetch',{url:safe},env,transport);if(typeof r.content!=='string'||!r.content.trim())throw new AppError('未获取到网页正文，请换一个来源；搜索摘要不能代替原文。',422);return {url:safe,title:typeof r.title==='string'?r.title:'网页资料',content:r.content,retrievedAt:new Date().toISOString()};}
