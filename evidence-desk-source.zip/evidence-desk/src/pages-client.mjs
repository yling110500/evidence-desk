import {handleApi} from './api.mjs';
// No service secret is bundled. Without a backend, only labeled reference fixtures run.
export function createPagesTransport(apiBase='',transport=fetch){
 return async function pagesRequest(path,options={}){
  if(!['config','analyze','chat','search','fetch','versions'].includes(path)&&!/^jobs\/[a-f0-9-]{36}$/.test(path))throw new Error('Unknown API path');
  if(apiBase)return transport(`${apiBase}/api/${path}`,options);
  return handleApi(new Request(`https://pages-reference.invalid/api/${path}`,options),{});
 };
}
