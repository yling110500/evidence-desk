import {AppError,validateInput,visibleSources,validateResult} from './core.mjs';
import {SOURCES,EXAMPLES} from './data.mjs';
import {referenceResult} from './reference.mjs';
import {SYSTEM_PROMPT} from './prompt.mjs';

const json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export function isConfigured(env){return !!(env.LLM_API_KEY&&env.LLM_API_URL&&env.LLM_MODEL);}
async function readInput(request){
 if(!request.headers.get('content-type')?.includes('application/json'))throw new AppError('请求必须为JSON。',415);
 const reader=request.body?.getReader();if(!reader)throw new AppError('请求为空。');
 const parts=[];let length=0;
 while(true){const {done,value}=await reader.read();if(done)break;length+=value.byteLength;if(length>524288){await reader.cancel();throw new AppError('输入过大，请减少材料。',413);}parts.push(value);}
 const bytes=new Uint8Array(length);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}
 try{return JSON.parse(new TextDecoder().decode(bytes));}catch{throw new AppError('请求不是有效的JSON。');}
}
export async function handleApi(request,env={},transport=fetch){
 const origin=request.headers.get('origin'),sameOrigin=new URL(request.url).origin;
 const allowed=String(env.ALLOWED_ORIGINS||'').split(',').map(x=>x.trim()).filter(Boolean);
 if(origin&&origin!==sameOrigin&&!allowed.includes(origin))return json({error:'此网页来源未被允许调用核验服务。'},403);
 const headers=origin?{'Access-Control-Allow-Origin':origin,'Vary':'Origin'}:{};
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{...headers,'Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Max-Age':'600'}});
 const response=await handleApiInternal(request,env,transport);
 for(const [key,value] of Object.entries(headers))response.headers.set(key,value);
 return response;
}
async function handleApiInternal(request,env,transport){
 try{
  const url=new URL(request.url);
  if(request.method==='GET'&&url.pathname==='/api/config')return json({liveReady:isConfigured(env),model:env.LLM_MODEL||null,accessCodeRequired:!!env.DEMO_ACCESS_CODE,sources:SOURCES,examples:EXAMPLES});
  if(url.pathname!=='/api/analyze')return json({error:'未找到接口。'},404);
  if(request.method!=='POST')return json({error:'请使用POST请求。'},405);
  const raw=await readInput(request);const input=validateInput(raw);
  if(!['reference','live'].includes(raw.mode))throw new AppError('请选择核验模式。');
  const sources=visibleSources(input.sources,input.asOf);
  if(!sources.length)throw new AppError('查询时点之前没有可用材料，请调整日期或补充材料。',422);
  const started=Date.now();let result,usage=null,upstreamRequestId=null;
  if(raw.mode==='reference')result=validateResult(referenceResult(input),input);
  else{
   if(env.DEMO_ACCESS_CODE&&request.headers.get('authorization')!==`Bearer ${env.DEMO_ACCESS_CODE}`)throw new AppError('体验码不正确，请在连接设置中填写。',401);
   if(!isConfigured(env))throw new AppError('尚未连接模型服务。请先在服务端配置模型，或选择“参考结果演示”查看原题案例。',503);
   let endpoint;try{endpoint=new URL(env.LLM_API_URL);}catch{throw new AppError('服务端模型地址配置有误。',503);}
   if(endpoint.protocol!=='https:'&&!(endpoint.protocol==='http:'&&['127.0.0.1','localhost'].includes(endpoint.hostname)))throw new AppError('模型服务必须使用HTTPS。',503);
   const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),90000);
   let response,body;
   try{
    const payload={model:env.LLM_MODEL,messages:[{role:'system',content:SYSTEM_PROMPT},{role:'user',content:JSON.stringify({...input,sources})}],stream:false};
    if(env.LLM_JSON_MODE!=='off')payload.response_format={type:'json_object'};
    response=await transport(endpoint.href,{method:'POST',headers:{Authorization:`Bearer ${env.LLM_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify(payload),signal:controller.signal});
    if(!response.ok)throw new AppError(response.status===429?'模型服务当前限流或额度不足，请稍后重试。':'模型服务调用失败，请检查服务配置、模型权限与账户额度。',502);
    const responseText=await response.text();
    if(responseText.length>250000)throw new AppError('模型返回内容过大，请缩短输入后重试。',502);
    try{body=JSON.parse(responseText);}catch{throw new AppError('模型服务返回了无效响应，请重试。',502);}
   }catch(e){if(e instanceof AppError)throw e;throw new AppError(controller.signal.aborted?'模型核验超时，请重试或缩短输入。':'暂时无法连接模型服务，请检查网络与配置。',502);}
   finally{clearTimeout(timer);}
   const choice=body.choices?.[0];
   if(choice?.finish_reason==='length')throw new AppError('模型输出被截断，请缩短输入或调整模型输出上限。',502);
   const content=choice?.message?.content;
   if(typeof content!=='string')throw new AppError('模型未返回文本核验结果。',502);
   let parsed;try{parsed=JSON.parse(content.replace(/^\s*```(?:json)?\s*/,'').replace(/\s*```\s*$/,''));}catch{throw new AppError('模型未返回有效的JSON，请重试；连续失败时请检查模型是否支持JSON输出。',502);}
   result=validateResult(parsed,input);usage=body.usage??null;upstreamRequestId=typeof body.id==='string'?body.id:null;
  }
  const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(input)));
  const inputHash=Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('');
  return json({...result,input,provenance:{runId:crypto.randomUUID(),mode:raw.mode,label:raw.mode==='live'?'真实模型运行':'人工编制参考结果，非模型运行',model:raw.mode==='live'?env.LLM_MODEL:null,promptVersion:raw.mode==='live'?'evidence-v1.0':null,createdAt:new Date().toISOString(),elapsedMs:Date.now()-started,inputHash,excludedSources:input.sources.filter(s=>s.publishedAt>input.asOf).map(s=>s.id),usage,upstreamRequestId}});
 }catch(e){return json({error:e instanceof AppError?e.message:'处理失败，请重试。'},e instanceof AppError?e.status:500);}
}
