import {AppError,validateInput,visibleSources,validateResult} from './core.mjs';
import {SOURCES,EXAMPLES} from './data.mjs';
import {referenceResult} from './reference.mjs';
import {SYSTEM_PROMPT} from './prompt.mjs';
import {searchWeb,fetchWebPage} from './search.mjs';
import {analyzeConversation} from './chat.mjs';
import {callModel} from './model.mjs';
import {detectVersionCandidates} from './versions.mjs';

const json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export function isConfigured(env){return !!(env.LLM_API_KEY&&env.LLM_API_URL&&env.LLM_MODEL);}
async function readInput(request){
 if(!request.headers.get('content-type')?.includes('application/json'))throw new AppError('请求必须为JSON。',415);
 const reader=request.body?.getReader();if(!reader)throw new AppError('请求为空。');
 const parts=[];let length=0;
 while(true){const {done,value}=await reader.read();if(done)break;length+=value.byteLength;if(length>524288){await reader.cancel();throw new AppError('输入过大，请减少材料。',413);}parts.push(value);}
 const bytes=new Uint8Array(length);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}
 try{return JSON.parse(new TextDecoder().decode(bytes));}catch{throw new AppError('请求不是有效的JSON。');}
}
export async function handleApi(request,env={},transport=fetch){
 const origin=request.headers.get('origin'),sameOrigin=new URL(request.url).origin;
 const allowed=String(env.ALLOWED_ORIGINS||'').split(',').map(x=>x.trim()).filter(Boolean);
 if(origin&&origin!==sameOrigin&&!allowed.includes(origin))return json({error:'此网页来源未被允许调用核验服务。'},403);
 const headers=origin?{'Access-Control-Allow-Origin':origin,'Vary':'Origin'}:{};
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{...headers,'Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Max-Age':'600'}});
 const response=await handleApiInternal(request,env,transport);
 for(const [key,value] of Object.entries(headers))response.headers.set(key,value);
 return response;
}
async function handleApiInternal(request,env,transport){
 try{
  const url=new URL(request.url);
  if(request.method==='GET'&&url.pathname==='/api/config')return json({liveReady:isConfigured(env),model:env.LLM_MODEL||null,accessCodeRequired:!!env.DEMO_ACCESS_CODE,sources:SOURCES,examples:EXAMPLES});
  if(['/api/search','/api/fetch','/api/chat','/api/versions'].includes(url.pathname)){
   if(request.method!=='POST')return json({error:'请使用POST请求。'},405);
   if(env.DEMO_ACCESS_CODE&&request.headers.get('authorization')!==`Bearer ${env.DEMO_ACCESS_CODE}`)throw new AppError('体验码不正确，请在连接设置中填写。',401);
   const raw=await readInput(request);
   if(url.pathname==='/api/chat')return json(await analyzeConversation(raw,env,transport));
   if(url.pathname==='/api/versions')return json({edges:await detectVersionCandidates(raw.documents,env,transport)});
   return json(url.pathname==='/api/search'?{results:await searchWeb(raw,env,transport)}:await fetchWebPage(raw,env,transport));
  }
  if(url.pathname!=='/api/analyze')return json({error:'未找到接口。'},404);
  if(request.method!=='POST')return json({error:'请使用POST请求。'},405);
  const raw=await readInput(request);const input=validateInput(raw);
  if(!['reference','live'].includes(raw.mode))throw new AppError('请选择核验模式。');
  const sources=visibleSources(input.sources,input.asOf);
  if(!sources.length)throw new AppError('查询时点之前没有可用材料，请调整日期或补充材料。',422);
  const started=Date.now();let result,usage=null,upstreamRequestId=null;
  if(raw.mode==='reference')result=validateResult(referenceResult(input),input);
  else{
   if(env.DEMO_ACCESS_CODE&&request.headers.get('authorization')!==`Bearer ${env.DEMO_ACCESS_CODE}`)throw new AppError('体验码不正确，请在连接设置中填写。',401);
   if(!isConfigured(env))throw new AppError('尚未连接模型服务。请先在服务端配置模型，或选择“参考结果演示”查看原题案例。',503);
   const model=await callModel({messages:[{role:'system',content:SYSTEM_PROMPT},{role:'user',content:JSON.stringify({...input,sources})}]},env,transport);
   result=validateResult(model.content,input);usage=model.usage;upstreamRequestId=model.requestId;
  }
  const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(input)));
  const inputHash=Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('');
  return json({...result,input,provenance:{runId:crypto.randomUUID(),mode:raw.mode,label:raw.mode==='live'?'真实模型运行':'人工编制参考结果，非模型运行',model:raw.mode==='live'?env.LLM_MODEL:null,promptVersion:raw.mode==='live'?'evidence-v1.0':null,createdAt:new Date().toISOString(),elapsedMs:Date.now()-started,inputHash,excludedSources:input.sources.filter(s=>s.publishedAt>input.asOf).map(s=>s.id),usage,upstreamRequestId}});
 }catch(e){return json({error:e instanceof AppError?e.message:'处理失败，请重试。'},e instanceof AppError?e.status:500);}
}
