export class AppError extends Error {
 constructor(message,status=400){super(message);this.status=status;}
}
export const normalize = x => String(x ?? '').replace(/\s+/gu,'');
function bounded(x,name,max,required=true){
 if(typeof x!=='string'||(required&&!x.trim())||x.length>max)throw new AppError(`${name}不能为空且不能超过${max}字。`);
 return x.trim();
}
function date(x,name){
 if(typeof x!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(x)||!Number.isFinite(Date.parse(x))||new Date(x).toISOString().slice(0,10)!==x)throw new AppError(`${name}不是有效日期。`);
 return x;
}
export function validateInput(raw){
 if(!raw||!['verify','query'].includes(raw.task))throw new AppError('请选择观点核验或临时查询。');
 const text=bounded(raw.text,'待核验内容',8000),asOf=date(raw.asOf,'查询时点');
 if(!Array.isArray(raw.sources)||!raw.sources.length||raw.sources.length>20)throw new AppError('请选择1至20份参考材料。');
 const ids=new Set();let total=0;
 const sources=raw.sources.map(s=>{
  if(!s||typeof s.id!=='string'||!/^S[1-9]\d{0,2}$/.test(s.id)||ids.has(s.id))throw new AppError('材料编号须为唯一的 S1—S999。');
  ids.add(s.id);const body=bounded(s.text,'材料正文',16000);total+=body.length;
  return {id:s.id,title:bounded(s.title,'材料标题',160),publisher:bounded(s.publisher,'来源',160),publishedAt:s.publishedAt===null?null:date(s.publishedAt,'发布日期'),period:bounded(s.period??'未注明','统计期',160),text:body,...(['sample','upload','web','manual'].includes(s.origin)?{origin:s.origin}:{})};
 });
 if(total>60000)throw new AppError('材料总长度不能超过60000字。');
 return {task:raw.task,text,asOf,sources};
}
export function visibleSources(sources,asOf){return sources.filter(s=>s.publishedAt===null||s.publishedAt<=asOf);}
export function validateResult(raw,input){
 if(!raw||typeof raw.summary!=='string'||!raw.summary.trim()||!Array.isArray(raw.claims)||!raw.claims.length||raw.claims.length>40)throw new AppError('模型结果结构不完整，请重新核验。',502);
 if(input.task==='query'&&(typeof raw.answer!=='string'||!raw.answer.trim()))throw new AppError('模型没有返回查询答案。',502);
 const warnings=[];const sources=visibleSources(input.sources,input.asOf);
 const claims=raw.claims.map((c,i)=>{
  if(!c||typeof c.text!=='string'||!c.text.trim()||c.text.length>8000||!['supported','contradicted','insufficient','conditional'].includes(c.status)||typeof c.reason!=='string'||!c.reason.trim()||!Array.isArray(c.evidence)||c.evidence.length>12)throw new AppError('模型的逐条核验结构不合法，请重新核验。',502);
  if(input.task==='verify'&&!normalize(input.text).includes(normalize(c.text)))throw new AppError('模型改写了待核验原文，结果未被接受，请重试。',502);
  let invalid=false,undated=false;
  const evidence=c.evidence.map(e=>{
   const s=sources.find(s=>s.id===e?.sourceId);
   const verified=!!(s&&typeof e.quote==='string'&&normalize(e.quote).length>=4&&normalize(s.text).includes(normalize(e.quote)));
   if(!verified)invalid=true;if(s&&s.publishedAt===null)undated=true;
   return {sourceId:typeof e?.sourceId==='string'?e.sourceId:'未知',quote:typeof e?.quote==='string'?e.quote:'',relation:['support','oppose','context'].includes(e?.relation)?e.relation:'context',verified,dateApplicable:!!s?.publishedAt};
  });
  if(!evidence.length&&c.status!=='insufficient')invalid=true;
  if(invalid)warnings.push(`第${i+1}项存在缺失或未匹配原文的引用，已降为证据不足，需人工复核。`);
  if(undated)warnings.push(`第${i+1}项引用了发布日期未知的资料：正文已匹配，但不能确认在核验时点前已公开，请补充日期。`);
  return {id:`C${i+1}`,text:c.text,status:invalid?'insufficient':undated?(c.status==='supported'?'conditional':c.status==='contradicted'?'insufficient':c.status):c.status,issue:typeof c.issue==='string'?c.issue:'待核验',reason:invalid?`${c.reason}（程序未能验证全部引用，请勿直接采用此结论。）`:undated?`${c.reason}（引用资料日期未知，历史时点适用性待确认。）`:c.reason,suggestion:typeof c.suggestion==='string'?c.suggestion:'',evidence};
 });
 let incomplete=false;
 if(input.task==='verify'){
  const original=normalize(input.text),covered=new Uint8Array(original.length);
  for(const c of claims){const phrase=normalize(c.text);let start=0,index;while((index=original.indexOf(phrase,start))!==-1){covered.fill(1,index,index+phrase.length);start=index+phrase.length;}}
  const unmatched=Array.from(original,(char,i)=>covered[i]?'\n':char).join('').split(/[\n。！？；，]+/u).map(x=>x.replace(/^[\p{P}\s]+|[\p{P}\s]+$/gu,'')).filter(x=>/[\p{L}\p{N}]/u.test(x));
  for(const text of unmatched){incomplete=true;claims.push({id:`C${claims.length+1}`,text,status:'insufficient',issue:'模型未覆盖此段',reason:'这段原文未被模型的核验项覆盖，尚未核验，不能据此判断支持或反驳。',suggestion:'请人工检查，或重新核验并确认拆解完整。',evidence:[]});}
  if(incomplete)warnings.push('部分输入原文未被模型覆盖，已补列为未核验项。');
 }
 const labels={supported:'有证据支持',conditional:'推断需限定',contradicted:'与材料不符',insufficient:'证据不足'};
 // The displayed query answer cannot introduce prose outside the checked claim list.
 const answer=input.task==='query'?`截至${input.asOf}，根据当前材料：${claims.map(c=>`${c.text}（${[...new Set(c.evidence.filter(e=>e.verified).map(e=>e.sourceId))].join('、')||'无匹配引用'}${c.status!=='supported'?`；${labels[c.status]}`:''}）`).join('；')}。采用依据与限制见下方逐项核验。`:'';
 return {summary:incomplete?'核验不完整：部分原文尚未被模型覆盖，请复核下方补列的未核验项。':raw.summary.slice(0,4000),answer,rewrite:typeof raw.rewrite==='string'?raw.rewrite.slice(0,12000):'',claims,warnings,answerNeedsReview:input.task==='query'&&claims.some(c=>c.status!=='supported')};
}
