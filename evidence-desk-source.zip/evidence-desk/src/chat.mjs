import {AppError,validateInput,validateResult,visibleSources} from './core.mjs';
import {SYSTEM_PROMPT} from './prompt.mjs';
import {callModel,provenance} from './model.mjs';
import {referenceResult} from './reference.mjs';
export async function analyzeConversation(raw,env,transport=fetch){
 if(!raw||!['verify','query','followup'].includes(raw.task)||typeof raw.message!=='string'||!raw.message.trim()||raw.message.length>8000)throw new AppError('请输入1—8000字的观点或问题。');
 const history=raw.history??[];
 if(!Array.isArray(history)||history.length>12||history.some(h=>!h||!['user','assistant'].includes(h.role)||typeof h.text!=='string')||history.reduce((n,h)=>n+h.text.length,0)>12000)throw new AppError('会话上下文过长或不合法，请新建会话。');
 const focusText=raw.task==='followup'?String(raw.focusText||'').slice(0,8000):raw.message;
 const input=validateInput({task:raw.task==='verify'?'verify':'query',text:raw.message,asOf:raw.asOf,sources:raw.sources});
 const sources=visibleSources(input.sources,input.asOf);if(!sources.length)throw new AppError('核验时点之前没有可用资料。',422);
 if(!['reference','live'].includes(raw.mode))throw new AppError('请选择真实核验或人工参考。');
 const started=Date.now();let result,usage=null,requestId=null;
 if(raw.mode==='reference'){if(raw.task==='followup')throw new AppError('人工参考不支持追问，请连接真实模型。',422);result=validateResult(referenceResult(input),input);}
 else{
  const context={...input,sources,message:raw.message,focusText,history,conversationTask:raw.task};
  const followup=raw.task==='followup'?'\n本轮是连续追问。focusText为本会话讨论的原观点，history只提供背景，不能当证据。回答当前message；需要改写时在rewrite给出完整建议。使用query规则，把回答里的事实/解释拆成带引用的claims；summary简洁回应问题，不能用过去的回答补造事实。':' ';
  const model=await callModel({messages:[{role:'system',content:SYSTEM_PROMPT+followup},{role:'user',content:JSON.stringify(context)}]},env,transport);
  result=validateResult(model.content,input);usage=model.usage;requestId=model.requestId;
 }
 return {...result,input,focusText,replyKind:raw.task,provenance:await provenance(input,env,{usage,requestId,started,mode:raw.mode})};
}
