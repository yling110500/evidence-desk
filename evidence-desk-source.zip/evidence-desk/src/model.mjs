import {AppError} from './core.mjs';
export async function callModel({messages,responseFormat=true},env,transport=fetch){
 if(!env.LLM_API_KEY||!env.LLM_MODEL||!env.LLM_API_URL)throw new AppError('尚未连接模型服务，请检查服务端配置。',503);
 let endpoint;try{endpoint=new URL(env.LLM_API_URL);}catch{throw new AppError('服务端模型地址配置有误。',503);}
 if(endpoint.protocol!=='https:'&&!(endpoint.protocol==='http:'&&['127.0.0.1','localhost'].includes(endpoint.hostname)))throw new AppError('模型服务必须使用HTTPS。',503);
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),90000);
 try{
  const payload={model:env.LLM_MODEL,messages,stream:false};if(responseFormat&&env.LLM_JSON_MODE!=='off')payload.response_format={type:'json_object'};
  const r=await transport(endpoint.href,{method:'POST',headers:{Authorization:`Bearer ${env.LLM_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify(payload),signal:controller.signal});
  if(!r.ok)throw new AppError(r.status===429?'模型服务限流，请稍后重试。':r.status===402?'模型账户余额不足。':'模型调用失败，请检查服务配置、权限与余额。',502);
  const text=await r.text();if(text.length>250000)throw new AppError('模型响应过大，请缩短输入。',502);
  let body;try{body=JSON.parse(text);}catch{throw new AppError('模型服务返回无效响应。',502);}
  const choice=body.choices?.[0];if(choice?.finish_reason==='length')throw new AppError('模型输出被截断，请缩短输入重试。',502);
  if(typeof choice?.message?.content!=='string')throw new AppError('模型没有返回文本结果。',502);
  let content;try{content=JSON.parse(choice.message.content.replace(/^\s*```(?:json)?\s*/,'').replace(/\s*```\s*$/,''));}catch{throw new AppError('模型未返回有效JSON，请重试。',502);}
  return {content,usage:body.usage??null,requestId:typeof body.id==='string'?body.id:null};
 }catch(e){if(e instanceof AppError)throw e;throw new AppError(controller.signal.aborted?'模型处理超时，请缩短输入重试。':'暂时无法连接模型服务。',502);}finally{clearTimeout(timer);}
}
export async function provenance(input,env,{usage=null,requestId=null,started=Date.now(),mode='live'}={}){
 const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(input)));
 return {runId:crypto.randomUUID(),mode,label:mode==='live'?'真实模型运行':'人工编制参考结果，非模型运行',model:mode==='live'?env.LLM_MODEL:null,promptVersion:'evidence-v2.0',createdAt:new Date().toISOString(),elapsedMs:Date.now()-started,inputHash:Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join(''),excludedSources:input.sources.filter(s=>s.publishedAt>input.asOf).map(s=>s.id),usage,upstreamRequestId:requestId};
}
