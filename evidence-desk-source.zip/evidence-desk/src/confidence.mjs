export function assessEvidence({hasFullText,quoteVerified=true,publishedAt,asOf,primaryConfirmed=false,anonymous=false,hasConflict=false}){
 const reasons=[];let level='medium',eligible=true;
 if(!hasFullText||!quoteVerified){level='unavailable';eligible=false;reasons.push('正文未获取或引用未匹配，不能作为已核验证据。');}
 else if(anonymous||hasConflict){level='low';reasons.push(anonymous?'匿名或未确认信息。':'存在尚未解决的数据冲突。');}
 else if(primaryConfirmed){level='high';reasons.push('用户确认的原始发布源，正文与引用可检查。');}
 else reasons.push('原文可查看，原始发布源身份仍需确认。');
 if(!publishedAt){reasons.push('发布日期未知，不用于保证历史时点结论。');if(level==='high')level='medium';}
 else if(publishedAt>asOf){eligible=false;reasons.push('发布日期晚于核验时点。');}
 return {level,reasons,eligible,historicallyApplicable:eligible&&!!publishedAt};
}
