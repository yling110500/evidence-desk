export function conversationIntent(message,task){
 const text=String(message).trim();
 if(/^(你好|您好|嗨|哈喽|在吗|hello|hi|hey)[！!。.?？\s]*$/iu.test(text))return 'guidance';
 if(task==='verify'&&(/[?？]$/.test(text)||/(多少|是什么|有哪些|为何|为什么)/u.test(text)))return 'query';
 return task;
}
export function greetingResult(message,asOf){
 if(typeof asOf!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(asOf)||!Number.isFinite(Date.parse(asOf))||new Date(asOf).toISOString().slice(0,10)!==asOf)throw new Error('请选择有效的核验时点。');
 return {summary:'你好，我是证研。你可以直接提出资料问题，或发送一段观点让我逐项核验。先从知识库勾选参考资料，也可以上传文件或搜索并收录网页原文。',answer:'',rewrite:'',claims:[],warnings:[],focusText:'',replyKind:'guidance',input:{task:'query',text:message,asOf,sources:[]},provenance:{runId:crypto.randomUUID(),mode:'guidance',label:'使用提示，未调用模型',model:null,createdAt:new Date().toISOString(),elapsedMs:0}};
}
