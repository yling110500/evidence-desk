const clone=x=>structuredClone(x);
const uid=()=>crypto.randomUUID();
const validDate=x=>typeof x==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(x)&&Number.isFinite(Date.parse(x))&&new Date(x).toISOString().slice(0,10)===x;
export function createWorkspace(sources,examples){
 const documents=sources.map(s=>({...clone(s),origin:'sample',revision:1,segments:[{text:s.text,paragraph:1}]}));
 const sessions=['A','B','Q'].map((key,i)=>({id:uid(),title:['观点1','观点2','临时查询'][i],task:examples[key].task,draft:examples[key].text,asOf:'2026-04-25',selectedSourceIds:documents.map(s=>s.id),webEnabled:false,messages:[],pendingRunId:null}));
 return {schemaVersion:2,sampleSetVersion:2,sourceCounter:6,activeSessionId:sessions[0].id,documents,sessions,versionEdges:[]};
}
export function upgradeSampleSet(w,sources,examples){
 if(w.sampleSetVersion>=2)return w;const next=clone(w);
 for(const d of next.documents){const current=sources.find(s=>s.id===d.id);if(d.origin!=='sample'||!current)continue;const legacyText=current.text.replace('据未具名行业人士透露','据某匿名行业人士透露'),legacyPublisher=current.publisher.replace('先进制造设备行业协会','先进制造装备行业协会');if(d.text===legacyText&&d.title===current.title&&d.publisher===legacyPublisher)Object.assign(d,current,{revision:(d.revision||1)+1,segments:[{text:current.text,paragraph:1}]});}
 const legacyA=examples.A.text.replace('启明设备第二季度','启明设备第一季度').replace('行业内公司','业内公司'),legacyB=examples.B.text.replace('行业2026年销售额','行业2026年全年销售额');
 for(const s of next.sessions){if(s.draft===legacyA)s.draft=examples.A.text;if(s.draft===legacyB)s.draft=examples.B.text;}
 next.sampleSetVersion=2;return next;
}
export function createSession(w,{title}={}){const next=clone(w),s={id:uid(),title:title?.trim().slice(0,60)||'新会话',task:'verify',draft:'',asOf:new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Shanghai'}),selectedSourceIds:[],webEnabled:false,messages:[],pendingRunId:null};next.sessions.push(s);next.activeSessionId=s.id;return next;}
export function updateSession(w,id,patch){const next=clone(w),s=next.sessions.find(s=>s.id===id);if(s){if(s.pendingRunId&&['selectedSourceIds','asOf'].some(k=>Object.hasOwn(patch,k)))throw new Error('正在等待回答，资料范围与核验时点已锁定。');Object.assign(s,patch,{id:s.id});if(Object.hasOwn(patch,'pendingRunId')&&!patch.pendingRunId){s.pendingScope=null;s.selectedSourceIds=s.selectedSourceIds.filter(id=>next.documents.some(d=>d.id===id));}}return next;}
export function beginSessionRun(w,id,runId){const next=clone(w),s=next.sessions.find(s=>s.id===id);if(!s||s.pendingRunId)throw new Error('会话正在处理或已不存在。');s.pendingScope={asOf:s.asOf,documents:s.selectedSourceIds.map(id=>next.documents.find(d=>d.id===id)).filter(Boolean).map(clone)};s.pendingRunId=runId;return next;}
export function sessionSources(w,s){return s?.pendingRunId&&s.pendingScope?s.pendingScope.documents:w.documents;}

export function removeSession(w,id){const next=clone(w);next.sessions=next.sessions.filter(s=>s.id!==id);if(next.activeSessionId===id)next.activeSessionId=next.sessions[0]?.id??null;return next;}
export function captureRun(w,id,{runId,message}){
 const s=w.sessions.find(s=>s.id===id);if(!s)throw new Error('会话已不存在。');if(!validDate(s.asOf))throw new Error('请选择有效的核验时点。');
 const selected=s.selectedSourceIds.map(id=>sessionSources(w,s).find(d=>d.id===id)).filter(Boolean),sources=[],excluded=[];
 for(const d of selected){if(d.publishedAt!==null&&(!validDate(d.publishedAt)||d.publishedAt>s.asOf))excluded.push({id:d.id,reason:d.publishedAt?'晚于核验时点':'发布日期未知'});else sources.push(clone(d));}
 return {sessionId:id,runId,message,task:s.task,asOf:s.asOf,sources,excluded,undatedSourceIds:sources.filter(d=>d.publishedAt===null).map(d=>d.id),capturedAt:new Date().toISOString()};
}
export function attachReply(w,{sessionId,runId,snapshot,result}){
 const next=clone(w),s=next.sessions.find(s=>s.id===sessionId);if(!s||s.pendingRunId!==runId)return next;
 s.messages.push({id:uid(),role:'assistant',text:result.summary,createdAt:new Date().toISOString(),snapshot:clone(snapshot),result:clone(result)});s.pendingRunId=null;s.pendingScope=null;s.selectedSourceIds=s.selectedSourceIds.filter(id=>next.documents.some(d=>d.id===id));return next;
}
export function nextSourceId(w){
 const used=[...(w.documents||[]).map(d=>d.id),...(w.versionEdges||[]).flatMap(e=>[e.oldId,e.newId]),...(w.sessions||[]).flatMap(s=>(s.messages||[]).flatMap(m=>[...(m.snapshot?.sources||[]),...(m.result?.input?.sources||[])].map(d=>d.id)))];
 const max=Math.max(6,w.sourceCounter||0,...used.map(id=>/^S[1-9]\d{0,2}$/.test(id)?Number(id.slice(1)):0));if(max>=999)throw new Error('资料编号已用完。');return `S${max+1}`;
}
export function serializeBackup(workspace,files=[]){return {format:'evidence-desk-backup',version:2,createdAt:new Date().toISOString(),workspace:clone(workspace),files};}
export function validateBackup(input,{requireFiles=true}={}){
 const raw=clone(input);
 if(!raw||raw.format!=='evidence-desk-backup'||raw.version!==2||!raw.workspace||!Array.isArray(raw.files))throw new Error('不是有效的证研备份。');
 const hasSecret=o=>o&&typeof o==='object'&&Object.entries(o).some(([k,v])=>/^(?:LLM_API_KEY|apiKey|accessCode|DEMO_ACCESS_CODE)$/i.test(k)||hasSecret(v));
 if(hasSecret(raw))throw new Error('备份不能包含密钥或体验码。');
 const w=raw.workspace;if(w.schemaVersion!==2||!Array.isArray(w.documents)||!Array.isArray(w.sessions)||!Array.isArray(w.versionEdges)||w.documents.length>999||w.sessions.length>200)throw new Error('备份结构不合法。');
 const validateDocument=d=>{
  if(!d||!/^S[1-9]\d{0,2}$/.test(d.id)||typeof d.text!=='string'||d.text.length>2000000||typeof d.title!=='string'||(d.publishedAt!==null&&!validDate(d.publishedAt)))throw new Error('资料编号、正文或日期不合法。');
  for(const k of ['publisher','period','origin','kind','fullText','url','fileId','originalName'])if(d[k]!==undefined&&typeof d[k]!=='string')throw new Error('资料元数据损坏。');
  if(d.segments!==undefined&&(!Array.isArray(d.segments)||d.segments.length>200000||d.segments.some(s=>!s||typeof s.text!=='string'||['page','paragraph'].some(k=>s[k]!==undefined&&(!Number.isSafeInteger(s[k])||s[k]<1)))))throw new Error('原文定位损坏。');
  if(d.revision!==undefined&&(!Number.isSafeInteger(d.revision)||d.revision<1))throw new Error('资料版本损坏。');
 };
 const ids=new Set();for(const d of w.documents){validateDocument(d);if(ids.has(d.id))throw new Error('资料编号重复。');ids.add(d.id);}
 const sessions=new Set();for(const s of w.sessions){if(!s||typeof s.id!=='string'||sessions.has(s.id)||typeof s.title!=='string'||typeof s.draft!=='string'||!validDate(s.asOf)||!['verify','query'].includes(s.task)||!Array.isArray(s.messages)||!Array.isArray(s.selectedSourceIds)||s.selectedSourceIds.some(id=>!ids.has(id)&&!s.pendingScope?.documents?.some(d=>d?.id===id)))throw new Error('会话数据不合法。');sessions.add(s.id);
  if(s.pendingScope!=null){if(!s.pendingScope||!validDate(s.pendingScope.asOf)||!Array.isArray(s.pendingScope.documents)||s.pendingScope.documents.length>20)throw new Error('等待中的资料范围损坏。');for(const d of s.pendingScope.documents)validateDocument(d);}
  s.pendingRunId=null;s.pendingScope=null;s.selectedSourceIds=s.selectedSourceIds.filter(id=>ids.has(id));
  for(const m of s.messages){if(!m||typeof m.id!=='string'||!['user','assistant'].includes(m.role)||m.role==='user'&&typeof m.text!=='string')throw new Error('会话消息损坏。');if(m.error){if(typeof m.error!=='string')throw new Error('错误消息损坏。');continue;}if(m.role==='assistant'){const r=m.result;if(!r||typeof r.summary!=='string'||typeof r.answer!=='string'||typeof r.rewrite!=='string'||!Array.isArray(r.claims)||!Array.isArray(r.warnings)||r.warnings.some(x=>typeof x!=='string')||!r.provenance||typeof r.provenance.runId!=='string'||!r.input||!validDate(r.input.asOf)||!Array.isArray(r.input.sources)||!m.snapshot||!Array.isArray(m.snapshot.sources))throw new Error('核验记录结构不合法。');for(const d of [...m.snapshot.sources,...r.input.sources])validateDocument(d);for(const c of r.claims){if(!c||!/^C\d+$/.test(c.id)||!['supported','contradicted','insufficient','conditional'].includes(c.status)||typeof c.text!=='string'||typeof c.reason!=='string'||typeof c.suggestion!=='string'||!Array.isArray(c.evidence)||c.evidence.some(e=>!e||typeof e.sourceId!=='string'||typeof e.quote!=='string'))throw new Error('核验项结构不合法。');}}}
 }
 for(const e of w.versionEdges)if(!e||typeof e.id!=='string'||!['revised','unchanged','possible'].includes(e.kind)||!['pending','confirmed','dismissed'].includes(e.review)||!['oldId','newId','metric','oldValue','newValue','oldQuote','newQuote'].every(k=>typeof e[k]==='string'))throw new Error('版本记录损坏。');
 if(w.sourceCounter!==undefined&&(!Number.isSafeInteger(w.sourceCounter)||w.sourceCounter<0||w.sourceCounter>999))throw new Error('资料编号计数损坏。');
 if(w.activeSessionId!==null&&!sessions.has(w.activeSessionId))throw new Error('当前会话不存在。');
 const fileIds=new Set();for(const f of raw.files){if(!f||typeof f.id!=='string'||fileIds.has(f.id)||typeof f.data!=='string'||f.data.length>15000000||!/^[A-Za-z0-9+/]*={0,2}$/.test(f.data))throw new Error('备份附件损坏。');fileIds.add(f.id);}
 if(requireFiles)for(const d of [...w.documents,...w.sessions.flatMap(s=>s.messages.flatMap(m=>m.snapshot?.sources||[]))])if(d.fileId&&!fileIds.has(d.fileId))throw new Error('备份缺少原文件附件。');
 return raw;
}
