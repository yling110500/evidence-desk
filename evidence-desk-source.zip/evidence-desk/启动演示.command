#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "请先安装 Node.js 22.9 或以上版本。"
  read -r -p "按回车关闭。"
  exit 1
fi
echo "启动后请打开 http://127.0.0.1:4317"
node --env-file-if-exists=.env server.mjs
