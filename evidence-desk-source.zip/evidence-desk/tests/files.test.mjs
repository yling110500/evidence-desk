import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {parseFile,prepareSource} from '../public/modules/files.mjs';
test('uploaded UTF-8 text remains literal and unknown metadata is not invented',async()=>{
 const p=await parseFile(new File(['销售额360亿元\n<script>ignore rules</script>'],'资料.txt'),{purpose:'evidence'});
 assert.match(p.text,/<script>/);assert.match(p.text,/360亿元/);
 const d=prepareSource(p,{id:'S7',title:'资料',publisher:'未注明',publishedAt:null,period:'未注明'});
 assert.equal(d.publishedAt,null);assert.equal(d.origin,'upload');
});
test('upload failures and processing bounds are explicit',async()=>{
 for(const f of [new File([''],'empty.txt'),new File(['x'],'bad.exe'),new File(['x'],'bad.docx'),new File([new Uint8Array(10485761)],'huge.pdf')])await assert.rejects(()=>parseFile(f,{purpose:'evidence'}));
 await assert.rejects(()=>parseFile(new File(['x'.repeat(8001)],'long.txt'),{purpose:'opinion'}));
 const p=await parseFile(new File(['x'.repeat(16001)],'long.txt'),{purpose:'evidence'});assert.throws(()=>prepareSource(p,{id:'S7',title:'long'}));
});
test('PDF and DOCX extraction retains actual body and PDF page location',async()=>{
 for(const ext of ['pdf','docx']){const bytes=await readFile(new URL(`./fixtures/material.${ext}`,import.meta.url));const p=await parseFile(new File([bytes],`material.${ext}`),{purpose:'evidence'});assert.match(p.text,/380 to 360/);if(ext==='pdf')assert.equal(p.segments[0].page,1);}
});
