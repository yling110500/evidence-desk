import test from 'node:test';
import assert from 'node:assert/strict';
import {IDBFactory} from 'fake-indexeddb';
import {openStorage} from '../public/modules/storage.mjs';
import {createWorkspace} from '../src/workspace.mjs';
import {SOURCES,EXAMPLES} from '../src/data.mjs';
test('storage failure or malformed import leaves the last saved workspace intact',async()=>{
 const factory=new IDBFactory(),store=await openStorage({factory,name:'test'}),w=createWorkspace(SOURCES,EXAMPLES);
 await store.save(w);await store.putFile('f1',new Blob(['body']));
 await assert.rejects(()=>store.save({...w,bad:()=>{}}));assert.equal((await store.load()).sessions.length,3);
 await assert.rejects(()=>store.importBackup({version:2}));assert.equal((await store.load()).documents.length,6);
 const b=await store.exportBackup();await store.importBackup(b);assert.equal(await(await store.getFile('f1')).text(),'body');
 const reopened=await openStorage({factory,name:'test'});assert.equal((await reopened.load()).sessions[0].title,'观点1');
});
