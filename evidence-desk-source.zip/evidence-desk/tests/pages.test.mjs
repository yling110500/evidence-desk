import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {buildPages} from '../scripts/build-pages.mjs';

test('Pages artifact works below a repository subpath without a server',async()=>{
 const out=await mkdtemp(join(tmpdir(),'evidence-pages-'));
 try{
  await buildPages(out);
  const html=await readFile(join(out,'index.html'),'utf8');
  for(const match of html.matchAll(/(?:src|href)="([^"#]+)"/g)){
   const url=new URL(match[1],'https://person.github.io/evidence-desk/');
   assert.ok(url.pathname.startsWith('/evidence-desk/'));
   await readFile(join(out,url.pathname.replace('/evidence-desk/','')));
  }
  const {createPagesTransport}=await import(pathToFileURL(join(out,'lib/pages-client.mjs')));
  const call=createPagesTransport('');
  const config=await (await call('config')).json();assert.equal(config.liveReady,false);
  const q=await call('analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...config.examples.Q,sources:config.sources,asOf:'2026-04-25',mode:'reference'})});
  assert.equal(q.status,200);const result=await q.json();assert.equal(result.provenance.mode,'reference');assert.match(result.answer,/360亿元/);
 }finally{await rm(out,{recursive:true,force:true});}
});
test('Pages does not pretend an unconfigured live call is a reference result',async()=>{
 const out=await mkdtemp(join(tmpdir(),'evidence-pages-'));
 try{
  await buildPages(out);
  const {createPagesTransport}=await import(pathToFileURL(join(out,'lib/pages-client.mjs')));
  const call=createPagesTransport(''),config=await(await call('config')).json();
  const r=await call('analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...config.examples.A,sources:config.sources,asOf:'2026-04-25',mode:'live'})});
  assert.equal(r.status,503);assert.match((await r.json()).error,/模型/);
 }finally{await rm(out,{recursive:true,force:true});}
});
