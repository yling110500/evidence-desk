import test from 'node:test';
import assert from 'node:assert/strict';
import {validateInput, visibleSources, validateResult} from '../src/core.mjs';

const source={id:'S1',title:'统计',publisher:'协会',publishedAt:'2026-04-08',period:'2026Q1',text:'销售额380亿元，同比增长18%。'};
const input={task:'verify',text:'销售额同比增长18%。',asOf:'2026-04-25',sources:[source]};
test('rejects empty text and impossible calendar dates',()=>{
 assert.throws(()=>validateInput({...input,text:' '}));
 assert.throws(()=>validateInput({...input,asOf:'2026-02-30'}));
 assert.equal(validateInput(input).text,'销售额同比增长18%。');
});
test('only allows unique source ids and bounded source text',()=>{
 assert.throws(()=>validateInput({...input,sources:[source,source]}));
 assert.throws(()=>validateInput({...input,sources:[{...source,text:'x'.repeat(16001)}]}));
});
test('excludes future sources but retains historical source evidence',()=>{
 const ss=[source,{...source,id:'S2',publishedAt:'2026-04-20'}];
 assert.deepEqual(visibleSources(ss,'2026-04-10').map(s=>s.id),['S1']);
 assert.equal(visibleSources(ss,'2026-04-25').length,2);
});
test('fabricated citations downgrade a supported claim for manual review',()=>{
 const raw={summary:'检查',answer:'',claims:[{text:input.text,status:'supported',issue:'事实',reason:'依据材料',suggestion:'',evidence:[{sourceId:'S1',quote:'销售额360亿元',relation:'support'}]}]};
 const result=validateResult(raw,input);
 assert.equal(result.claims[0].status,'insufficient');
 assert.equal(result.claims[0].evidence[0].verified,false);
 assert.ok(result.warnings.length);
});
test('verified literal quotations retain claim status',()=>{
 const result=validateResult({summary:'核验',claims:[{text:input.text,status:'supported',issue:'事实',reason:'匹配',evidence:[{sourceId:'S1',quote:'同比增长18%',relation:'support'}]}]},input);
 assert.equal(result.claims[0].evidence[0].verified,true);
 assert.equal(result.claims[0].status,'supported');
});
test('rejects empty, arbitrary and malformed model output',()=>{
 assert.throws(()=>validateResult({summary:'好',claims:[]},input));
 assert.throws(()=>validateResult({summary:'好',claims:[{text:'编造另一段观点',status:'supported',reason:'对',evidence:[]}]},input));
 assert.throws(()=>validateResult({summary:'好',claims:[{text:input.text,status:'whatever',reason:'对',evidence:[]}]},input));
});
test('omitted input assertions remain visible as unchecked claims',()=>{
 const i={...input,text:'销售额同比增长18%。所有企业收入已经翻倍。'};
 const r=validateResult({summary:'全部有依据',claims:[{text:'销售额同比增长18%',status:'supported',reason:'初步值',evidence:[{sourceId:'S1',quote:'同比增长18%',relation:'support'}]}]},i);
 assert.ok(r.claims.some(c=>c.text.includes('所有企业收入已经翻倍')&&c.status==='insufficient'));
 assert.ok(r.warnings.length);assert.match(r.summary,/不完整/);
});
test('query answer is constructed from checked claims rather than unbound model prose',()=>{
 const i={...input,task:'query',text:'销售额是多少？'};
 const r=validateResult({summary:'查询完成',answer:'销售额9999亿元。所有企业收入翻倍。',claims:[{text:'销售额380亿元',status:'supported',reason:'初步统计',evidence:[{sourceId:'S1',quote:'销售额380亿元',relation:'support'}]}]},i);
 assert.match(r.answer,/380亿元/);assert.doesNotMatch(r.answer,/9999|翻倍/);
});
