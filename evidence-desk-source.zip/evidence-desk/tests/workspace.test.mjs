import test from 'node:test';
import assert from 'node:assert/strict';
import {createWorkspace,createSession,updateSession,removeSession,captureRun,attachReply,serializeBackup,validateBackup,upgradeSampleSet,nextSourceId} from '../src/workspace.mjs';
import {SOURCES,EXAMPLES} from '../src/data.mjs';
test('sessions preserve independent selections and immutable run snapshots',()=>{
 let w=createWorkspace(SOURCES,EXAMPLES);
 assert.deepEqual(w.sessions.map(s=>s.title),['观点1','观点2','临时查询']);
 assert.equal(w.sessions[0].draft,EXAMPLES.A.text);assert.equal(w.documents.length,6);
 const id=w.sessions[0].id,other=w.sessions[1].id;
 w=updateSession(w,id,{selectedSourceIds:['S1'],draft:'新观点'});
 assert.equal(w.sessions.find(s=>s.id===other).selectedSourceIds.length,6);
 const snapshot=captureRun(w,id,{runId:'r1',message:'新观点'});
 w.documents[0].text='changed';assert.match(snapshot.sources[0].text,/380/);
 w=createSession(w,{});assert.deepEqual(w.sessions.at(-1).selectedSourceIds,[]);
});
test('backup rejects unsafe page locations, malformed segments and nested null source snapshots',()=>{
 const base=serializeBackup(createWorkspace(SOURCES,EXAMPLES),[]);
 for(const segments of [[{text:'safe',page:'<img src=x onerror=alert(1)>'}],{length:1},[{text:'safe',paragraph:-1}]]){const b=structuredClone(base);b.workspace.documents[0].segments=segments;assert.throws(()=>validateBackup(b));}
 const b=structuredClone(base);b.workspace.sessions[0].messages=[{id:'m',role:'assistant',snapshot:{sources:[null],asOf:'2026-04-25'},result:{summary:'x',answer:'',rewrite:'',claims:[],warnings:[],input:{asOf:'2026-04-25',sources:SOURCES},provenance:{mode:'live',runId:'r'}}}];assert.throws(()=>validateBackup(b));
});
test('deleted evidence identifiers are never reassigned to unrelated new documents',()=>{const w=createWorkspace(SOURCES,EXAMPLES);w.versionEdges=[{oldId:'S1',newId:'S2'}];w.documents=w.documents.filter(d=>d.id!=='S1');assert.equal(nextSourceId(w),'S7');});
test('late replies stay with their session and deleted sessions never resurrect',()=>{
 let w=createWorkspace(SOURCES,EXAMPLES),id=w.sessions[0].id;
 const snapshot=captureRun(w,id,{runId:'r1',message:w.sessions[0].draft});
 w=updateSession(w,id,{pendingRunId:'r1'});w.activeSessionId=w.sessions[1].id;
 w=attachReply(w,{sessionId:id,runId:'r1',snapshot,result:{summary:'ok'}});
 assert.equal(w.sessions[0].messages.length,1);assert.equal(w.sessions[1].messages.length,0);
 w=removeSession(w,id);const count=w.sessions.length;
 w=attachReply(w,{sessionId:id,runId:'r1',snapshot,result:{summary:'late'}});assert.equal(w.sessions.length,count);
});
test('snapshots include undated selected sources with a warning and exclude only future publications',()=>{
 const w=createWorkspace(SOURCES,EXAMPLES),s=w.sessions[0];s.asOf='2026-04-10';w.documents[0].publishedAt=null;
 const snapshot=captureRun(w,s.id,{runId:'r',message:'test'});
 assert.deepEqual(snapshot.sources.map(s=>s.id),['S1','S3','S4','S6']);assert.equal(snapshot.excluded.length,2);assert.equal(snapshot.sources[0].publishedAt,null);assert.deepEqual(snapshot.undatedSourceIds,['S1']);
});
test('backups reject duplicate IDs, invalid dates and credential fields atomically',()=>{
 const w=createWorkspace(SOURCES,EXAMPLES),b=serializeBackup(w,[]);
 assert.equal(validateBackup(b).workspace.sessions.length,3);
 const duplicate=structuredClone(b);duplicate.workspace.documents.push(duplicate.workspace.documents[0]);assert.throws(()=>validateBackup(duplicate));
 const invalid=structuredClone(b);invalid.workspace.documents[0].publishedAt='2026-02-30';assert.throws(()=>validateBackup(invalid));
 assert.throws(()=>validateBackup({...b,LLM_API_KEY:'private'}));
 const malformed=structuredClone(b);malformed.workspace.sessions[0].messages=[{id:'bad',role:'assistant',result:{claims:[{status:'supported" onclick="bad'}]}}];assert.throws(()=>validateBackup(malformed));
 assert.equal(w.documents.length,6);
});
test('sample transcription migration corrects only untouched examples and retains history and user edits',()=>{
 const w=createWorkspace(SOURCES,EXAMPLES);delete w.sampleSetVersion;w.sessions[0].draft=EXAMPLES.A.text.replace('启明设备第二季度','启明设备第一季度').replace('行业内公司','业内公司');w.sessions[1].draft='用户自己修改的观点';w.documents=w.documents.filter(d=>d.id!=='S4');w.documents[0].publisher='先进制造装备行业协会';w.sessions[2].messages=[{id:'old',snapshot:{sources:[{text:'历史原文'}]}}];
 const next=upgradeSampleSet(w,SOURCES,EXAMPLES);assert.equal(next.sessions[0].draft,EXAMPLES.A.text);assert.equal(next.sessions[1].draft,'用户自己修改的观点');assert.equal(next.documents.length,5);assert.equal(next.documents[0].publisher,'先进制造设备行业协会');assert.equal(next.sessions[2].messages[0].snapshot.sources[0].text,'历史原文');
});
test('waiting locks source selection and cutoff; completion or stopping allows changing the next round',async()=>{
 const {beginSessionRun}=await import('../src/workspace.mjs');
 let w=createWorkspace(SOURCES,EXAMPLES),id=w.activeSessionId;
 w=updateSession(w,id,{selectedSourceIds:['S1']});const snapshot=captureRun(w,id,{runId:'r1',message:'原问题'});w=beginSessionRun(w,id,'r1');
 assert.throws(()=>updateSession(w,id,{selectedSourceIds:['S2']}),/锁定/);assert.throws(()=>updateSession(w,id,{asOf:'2026-05-01'}),/锁定/);
 w.documents[0].text='新版正文';assert.match(captureRun(w,id,{runId:'r1',message:'原问题'}).sources[0].text,/380亿元/);
 w=attachReply(w,{sessionId:id,runId:'r1',snapshot,result:{summary:'回答'}});w=updateSession(w,id,{selectedSourceIds:['S2'],asOf:'2026-05-01'});assert.equal(w.sessions[0].selectedSourceIds[0],'S2');assert.match(w.sessions[0].messages[0].snapshot.sources[0].text,/380亿元/);
 w=beginSessionRun(w,id,'r2');w=updateSession(w,id,{pendingRunId:null});w=updateSession(w,id,{selectedSourceIds:['S3']});assert.equal(w.sessions[0].pendingScope,null);assert.equal(w.sessions[0].selectedSourceIds[0],'S3');
});
