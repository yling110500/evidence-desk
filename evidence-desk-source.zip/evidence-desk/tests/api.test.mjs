import test from 'node:test';
import assert from 'node:assert/strict';
import {handleApi} from '../src/api.mjs';
import {SOURCES,EXAMPLES} from '../src/data.mjs';
const payload=(id='A')=>({...EXAMPLES[id],asOf:'2026-04-25',sources:SOURCES,mode:'reference'});
const request=(body,headers={})=>new Request('http://localhost/api/analyze',{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify(body)});
test('reference cases retain matching source quotes and honest provenance',async()=>{
 for(const id of ['A','B','Q']){
  const r=await handleApi(request(payload(id)),{});assert.equal(r.status,200);
  const j=await r.json();assert.equal(j.provenance.mode,'reference');assert.equal(j.warnings.length,0);
  assert.ok(j.claims.every(c=>c.evidence.every(e=>e.verified)));
  if(id==='Q'){assert.match(j.answer,/360亿元/);assert.match(j.answer,/12%/);}
 }
});
test('reference cannot impersonate dynamic analysis after input changes',async()=>{
 const p=payload();p.text=p.text.replace('18%','12%');
 assert.equal((await handleApi(request(p),{})).status,422);
 p.text=EXAMPLES.A.text;p.sources=p.sources.filter(s=>s.id!=='S2');
 assert.equal((await handleApi(request(p),{})).status,422);
});
test('unconfigured live mode returns a clear error instead of a fixture',async()=>{
 const r=await handleApi(request({...payload(),mode:'live'}),{});
 assert.equal(r.status,503);assert.match((await r.json()).error,/模型/);
});
test('cross origin mutations are rejected',async()=>{
 assert.equal((await handleApi(request(payload(),{origin:'https://untrusted.example'}),{})).status,403);
});
test('upstream errors never disclose secrets or return success',async()=>{
 const env={LLM_API_URL:'https://model.example/chat/completions',LLM_MODEL:'test-model',LLM_API_KEY:'sensitive-key'};
 const r=await handleApi(request({...payload(),mode:'live'}),env,async()=>new Response('sensitive-key',{status:401}));
 assert.equal(r.status,502);assert.doesNotMatch(await r.text(),/sensitive-key/);
});
test('live request excludes future sources and validates upstream output',async()=>{
 const p={...payload('Q'),asOf:'2026-04-10',mode:'live'};
 const env={LLM_API_URL:'https://model.example/chat/completions',LLM_MODEL:'test-model',LLM_API_KEY:'sensitive-key'};
 const transport=async(url,options)=>{
  const req=JSON.parse(options.body),u=JSON.parse(req.messages[1].content);
  assert.deepEqual(u.sources.map(s=>s.id),['S1','S3','S4','S6']);
  assert.equal(options.headers.Authorization,'Bearer sensitive-key');
  return Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify({summary:'初步值',answer:'380亿元，同比增长18%',claims:[{text:'380亿元，同比增长18%',status:'supported',reason:'初步统计',issue:'初步值',evidence:[{sourceId:'S1',quote:'销售额为380亿元，同比增长18%',relation:'support'}]}]})}}],usage:{total_tokens:100}});
 };
 const r=await handleApi(request(p),env,transport);assert.equal(r.status,200);
 const j=await r.json();assert.equal(j.provenance.mode,'live');assert.equal(j.provenance.model,'test-model');assert.deepEqual(j.provenance.excludedSources,['S2','S5']);
});
test('access code gates live model spending but not reference examples',async()=>{
 const env={DEMO_ACCESS_CODE:'secret',LLM_API_KEY:'key',LLM_API_URL:'https://model.example/chat/completions',LLM_MODEL:'m'};
 assert.equal((await handleApi(request({...payload(),mode:'live'}),env)).status,401);
 assert.equal((await handleApi(request(payload()),env)).status,200);
});
test('explicitly allowed Pages origin can preflight and receive analysis',async()=>{
 const env={ALLOWED_ORIGINS:'https://person.github.io'};
 const preflight=await handleApi(new Request('https://api.example/api/analyze',{method:'OPTIONS',headers:{origin:'https://person.github.io','Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'content-type,authorization'}}),env);
 assert.equal(preflight.status,204);assert.equal(preflight.headers.get('access-control-allow-origin'),'https://person.github.io');
 const r=await handleApi(request(payload(),{origin:'https://person.github.io'}),env);
 assert.equal(r.status,200);assert.equal(r.headers.get('access-control-allow-origin'),'https://person.github.io');
 const bad=await handleApi(request(payload(),{origin:'https://other.github.io'}),env);
 assert.equal(bad.status,403);assert.equal(bad.headers.get('access-control-allow-origin'),null);
});
test('a newly collected undated seventh source reaches the model and remains visible in the result',async()=>{
 const added={id:'S7',title:'新增研究资料',publisher:'用户提供',publishedAt:null,period:'未注明',origin:'manual',text:'这份新增资料记载试验批次为42批。'};
 const body={message:'新增资料记载的试验批次是多少？',task:'query',sources:[...SOURCES,added],asOf:'2026-04-25',mode:'live'};
 const req=new Request('https://api.example/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 const env={LLM_API_URL:'https://model.example/chat/completions',LLM_MODEL:'test-model',LLM_API_KEY:'sensitive-key'};
 const r=await handleApi(req,env,async(url,options)=>{const context=JSON.parse(JSON.parse(options.body).messages[1].content);assert.equal(context.sources.length,7);assert.equal(context.sources[6].publishedAt,null);assert.equal(context.sources[6].text,added.text);return Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify({summary:'新增资料记载42批，日期待核',answer:'42批',claims:[{text:'新增资料记载试验批次为42批。',status:'supported',reason:'依据新增原文',evidence:[{sourceId:'S7',quote:'试验批次为42批',relation:'support'}]}]})}}]});});
 assert.equal(r.status,200);const result=await r.json();assert.equal(result.input.sources.length,7);assert.match(result.answer,/42批/);assert.equal(result.claims[0].evidence[0].verified,true);assert.equal(result.claims[0].status,'conditional');
});
