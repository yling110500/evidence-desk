import test from 'node:test';import assert from 'node:assert/strict';
import {validateVersionEdges,documentVersionStatus,affectedSessions,SAMPLE_EDGES} from '../src/versions.mjs';import {createWorkspace} from '../src/workspace.mjs';import {SOURCES,EXAMPLES} from '../src/data.mjs';
test('field revisions preserve unchanged values and respect historical time',()=>{
 const edges=validateVersionEdges(SAMPLE_EDGES,SOURCES);
 assert.equal(edges.filter(e=>e.kind==='revised').length,2);assert.equal(edges.find(e=>e.oldValue==='35%').kind,'unchanged');
 assert.equal(documentVersionStatus('S1',edges,{asOf:'2026-04-10'}).items.length,0);
 assert.equal(documentVersionStatus('S1',edges,{asOf:'2026-04-25'}).items.length,3);
});
test('same publisher and period cannot turn another companys data into a revision',()=>{
 const docs=[{id:'S7',title:'甲公司收入',publisher:'行业媒体',publishedAt:'2026-04-01',period:'2026Q1',text:'甲公司营业收入100亿元。'},{id:'S8',title:'乙公司更正',publisher:'行业媒体',publishedAt:'2026-04-02',period:'2026Q1',text:'乙公司营业收入由100亿元修订为90亿元。'}];
 const edges=validateVersionEdges([{oldId:'S7',newId:'S8',entity:'甲公司',period:'2026Q1',metric:'营业收入',oldValue:'100亿元',newValue:'90亿元',oldQuote:docs[0].text,newQuote:docs[1].text,kind:'revised'}],docs);assert.equal(edges[0].kind,'possible');
});
test('unmatched quotes and incomparable periods or units never become confirmed revisions',()=>{
 assert.equal(validateVersionEdges([{...SAMPLE_EDGES[0],oldQuote:'不存在'}],SOURCES).length,0);
 const docs=structuredClone(SOURCES);docs[1].period='2025年第一季度';assert.equal(validateVersionEdges([SAMPLE_EDGES[0]],docs)[0].kind,'possible');
 assert.equal(validateVersionEdges([{...SAMPLE_EDGES[0],newValue:'360万元'}],SOURCES).length,0);
});
test('only conversations citing changed metrics need rechecking, never future revisions',()=>{
 const w=createWorkspace(SOURCES,EXAMPLES);w.versionEdges=validateVersionEdges(SAMPLE_EDGES,w.documents);
 const result=text=>({claims:[{text,reason:'原文',evidence:[{sourceId:'S1',quote:SOURCES[0].text}]}]});
 w.sessions[0].messages=[{id:'m1',result:result('同比18%'),snapshot:{asOf:'2026-04-25'}}];w.sessions[1].messages=[{id:'m2',result:result('先进封装35%'),snapshot:{asOf:'2026-04-25'}}];
 assert.deepEqual(affectedSessions(w,w.versionEdges).map(x=>x.messageId),['m1']);w.sessions[0].messages[0].snapshot.asOf='2026-04-10';assert.equal(affectedSessions(w,w.versionEdges).length,0);
});
test('an answer already using the revision source is not falsely marked outdated',()=>{
 const w=createWorkspace(SOURCES,EXAMPLES),edges=validateVersionEdges(SAMPLE_EDGES,w.documents);
 w.sessions[0].messages=[{id:'current',snapshot:{asOf:'2026-04-25',sources:structuredClone(SOURCES)},result:{claims:[{text:'初步18%已修订为12%',reason:'采用修订统计',evidence:[{sourceId:'S1',quote:SOURCES[0].text},{sourceId:'S2',quote:SOURCES[1].text}]}]}}];
 assert.equal(affectedSessions(w,edges).length,0);
});
