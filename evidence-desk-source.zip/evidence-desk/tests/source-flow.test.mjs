import test from 'node:test';import assert from 'node:assert/strict';import {createWorkspace} from '../src/workspace.mjs';import {SOURCES,EXAMPLES} from '../src/data.mjs';import {saveDocument} from '../public/modules/source-save.mjs';import {createClient} from '../public/modules/client.mjs';
test('saving an attachment merges into the newest workspace and preserves replies received while writing',async()=>{
 let w=createWorkspace(SOURCES,EXAMPLES),resolveWrite;const id=w.sessions[0].id;w.sessions[0].pendingRunId='r';
 const pending=saveDocument({getWorkspace:()=>w,setWorkspace:x=>w=x,storage:{putFile:()=>new Promise(r=>resolveWrite=r)},sessionId:id,parsed:{name:'sample.txt',text:'Revenue360',segments:[{text:'Revenue360',paragraph:1}],original:new Blob(['Revenue360'])},metadata:{title:'上传',publisher:'测试',publishedAt:'2026-04-01',period:'2026Q1'},text:'Revenue360'});
 w.sessions[0].messages.push({id:'reply',role:'assistant',text:'completed'});w.sessions[0].pendingRunId=null;resolveWrite();await pending;assert.equal(w.sessions[0].messages[0].text,'completed');assert.equal(w.sessions[0].pendingRunId,null);assert.equal(w.documents.length,7);
});
test('chat and version requests send only the selected excerpt and allowed metadata',async()=>{
 const d={...SOURCES[0],text:'选中的短段',fullText:'x'.repeat(300000),segments:[{text:'x'.repeat(300000),page:1}]},bodies=[];
 const client=createClient({transport:async(url,options)=>{bodies.push(JSON.parse(options.body));return Response.json({ok:true});}});
 await client.chat({sources:[d],message:'观点'});await client.versions({documents:[d]});await client.analyze({sources:[d]});
 for(const body of bodies){assert.ok(JSON.stringify(body).length<10000);const doc=(body.sources||body.documents)[0];assert.equal(doc.text,'选中的短段');assert.equal(doc.fullText,undefined);assert.equal(doc.segments,undefined);}
});
test('connection checking has a bounded wait so unavailable backend cannot hold the workspace forever',async()=>{
 const client=createClient({configTimeoutMs:10,transport:async(url,options)=>{assert.ok(options.signal,'config must have an abort signal');return new Promise((resolve,reject)=>options.signal.addEventListener('abort',()=>reject(options.signal.reason),{once:true}));}});
 const alive=setTimeout(()=>{},100);try{await assert.rejects(client.config(),/超时/);}finally{clearTimeout(alive);}
});
