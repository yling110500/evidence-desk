import test from 'node:test';import assert from 'node:assert/strict';import {createWorkspace} from '../src/workspace.mjs';import {SOURCES,EXAMPLES} from '../src/data.mjs';import {saveDocument} from '../public/modules/source-save.mjs';import {createClient} from '../public/modules/client.mjs';
test('collecting a new webpage allocates an id and keeps original text and URL',async()=>{
 let w=createWorkspace(SOURCES,EXAMPLES);const sessionId=w.activeSessionId;
 const web={id:null,title:'网页资料',publisher:'example.org',origin:'web',url:'https://example.org/report',text:'实际抓取的网页正文',fullText:'实际抓取的网页正文',segments:[{text:'实际抓取的网页正文',paragraph:1}]};
 const d=await saveDocument({getWorkspace:()=>w,setWorkspace:x=>w=x,sessionId,editing:web,metadata:{title:web.title,publisher:web.publisher,publishedAt:null,period:'未注明'},text:web.text});
 assert.equal(d.id,'S7');assert.equal(d.url,web.url);assert.equal(d.fullText,web.fullText);assert.ok(w.sessions.find(s=>s.id===sessionId).selectedSourceIds.includes(d.id));
 await assert.rejects(saveDocument({getWorkspace:()=>w,setWorkspace:x=>w=x,sessionId,editing:{...web,id:'S99'},metadata:{title:web.title},text:web.text}),/已被移除/);
});
test('saving an attachment merges into the newest workspace and preserves replies received while writing',async()=>{
 let w=createWorkspace(SOURCES,EXAMPLES),resolveWrite;const id=w.sessions[0].id;w.sessions[0].pendingRunId='r';
 const pending=saveDocument({getWorkspace:()=>w,setWorkspace:x=>w=x,storage:{putFile:()=>new Promise(r=>resolveWrite=r)},sessionId:id,parsed:{name:'sample.txt',text:'Revenue360',segments:[{text:'Revenue360',paragraph:1}],original:new Blob(['Revenue360'])},metadata:{title:'上传',publisher:'测试',publishedAt:'2026-04-01',period:'2026Q1'},text:'Revenue360'});
 w.sessions[0].messages.push({id:'reply',role:'assistant',text:'completed'});w.sessions[0].pendingRunId=null;resolveWrite();await pending;assert.equal(w.sessions[0].messages[0].text,'completed');assert.equal(w.sessions[0].pendingRunId,null);assert.equal(w.documents.length,7);
});
test('chat and version requests send only the selected excerpt and allowed metadata',async()=>{
 const d={...SOURCES[0],text:'选中的短段',fullText:'x'.repeat(300000),segments:[{text:'x'.repeat(300000),page:1}]},bodies=[];
 const client=createClient({transport:async(url,options)=>{bodies.push(JSON.parse(options.body));return Response.json({ok:true});}});
 await client.chat({sources:[d],message:'观点'});await client.versions({documents:[d]});await client.analyze({sources:[d]});
 for(const body of bodies){assert.ok(JSON.stringify(body).length<10000);const doc=(body.sources||body.documents)[0];assert.equal(doc.text,'选中的短段');assert.equal(doc.fullText,undefined);assert.equal(doc.segments,undefined);}
});
test('connection checking has a bounded wait so unavailable backend cannot hold the workspace forever',async()=>{
 const client=createClient({configTimeoutMs:10,transport:async(url,options)=>{assert.ok(options.signal,'config must have an abort signal');return new Promise((resolve,reject)=>options.signal.addEventListener('abort',()=>reject(options.signal.reason),{once:true}));}});
 const alive=setTimeout(()=>{},100);try{await assert.rejects(client.config(),/超时/);}finally{clearTimeout(alive);}
});
test('long model calls submit once and poll authenticated results, including on static Pages',async()=>{
 const calls=[],id='d3b9d4a8-9f6e-4567-894b-e21347890123';
 const client=createClient({apiBase:'https://demo.example',staticMode:true,accessCode:()=> 'demo-code',pollIntervalMs:0,transport:async(url,options)=>{
  calls.push({url,options});assert.equal(options.headers.Authorization,'Bearer demo-code');
  return calls.length<3?Response.json({jobId:id,status:'pending'},{status:202}):Response.json({summary:'完整结果'});
 }});
 assert.equal((await client.chat({message:'观点'})).summary,'完整结果');assert.equal(calls.filter(c=>c.options.method==='POST').length,1);assert.ok(calls[1].url.endsWith('/api/jobs/'+id));assert.equal(calls[1].options.method,'GET');
});
test('job failure stays an error and canceling polling never submits a second model call',async()=>{
 let count=0;const client=createClient({pollIntervalMs:0,transport:async()=>++count===1?Response.json({jobId:'d3b9d4a8-9f6e-4567-894b-e21347890123'},{status:202}):Response.json({error:'模型处理失败'},{status:502})});await assert.rejects(client.chat({}),/模型处理失败/);assert.equal(count,2);
 const controller=new AbortController();count=0;const canceled=createClient({pollIntervalMs:100,transport:async()=>{count++;controller.abort();return Response.json({jobId:'d3b9d4a8-9f6e-4567-894b-e21347890123'},{status:202});}});await assert.rejects(canceled.chat({},controller.signal),e=>e.name==='AbortError');assert.equal(count,1);
});
