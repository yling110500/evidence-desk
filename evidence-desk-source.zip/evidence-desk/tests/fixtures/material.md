# Material
Revenue revised from 380 to 360. Growth revised from 18% to 12%.