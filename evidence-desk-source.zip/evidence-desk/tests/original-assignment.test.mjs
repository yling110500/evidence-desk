import test from 'node:test';import assert from 'node:assert/strict';import {SOURCES,EXAMPLES} from '../src/data.mjs';import {referenceResult} from '../src/reference.mjs';import {validateResult} from '../src/core.mjs';
test('built-in examples preserve the actual PDF wording and identify expectation versus realized fact',()=>{
 assert.match(EXAMPLES.A.text,/启明设备第二季度产能利用率已经超过85%/);assert.match(EXAMPLES.A.text,/充分证明行业内公司都在加速扩产/);
 assert.match(EXAMPLES.B.text,/研究机构预测行业2026年销售额可能增长20%左右/);assert.equal(SOURCES[0].publisher,'先进制造设备行业协会');assert.match(SOURCES[5].text,/据未具名行业人士透露/);
 const input={task:'verify',text:EXAMPLES.A.text,asOf:'2026-04-25',sources:SOURCES};const result=validateResult(referenceResult(input),input);assert.equal(result.warnings.length,0);assert.ok(result.claims.some(c=>c.text==='启明设备第二季度产能利用率已经超过85%'&&/预期/.test(c.reason)));
});
