# Conversational Evidence Desk Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将已连接真实模型的投研助手改为三个默认会话、独立知识库、真实上传、可追溯联网检索及按指标生效的版本提醒。

**Architecture:** 保留原生浏览器界面与 Node/Web Fetch 后端。浏览器通过 IndexedDB 保存会话、资料、原文件与版本关系；后端负责模型调用、搜索／正文抓取及输出校验。每次请求冻结会话与资料快照，历史模型回复不能成为新一轮核验的证据。

**Tech Stack:** 原生 HTML/CSS/ES modules、Node.js、IndexedDB；PDF.js 解析文字型 PDF、Mammoth 提取 DOCX 纯文本、esbuild 构建模块。依赖在执行时从官方 npm 包安装并锁定版本，核对其 Node 要求，README 声明实际要求；不把第三方解析脚本通过 CDN 注入产品页面。

**Spec:** `/Users/bytedance/Documents/Codex/2026-10-17/zhe/outputs/新版交互与知识库方案.html`（用户于2026-10-17确认；仓库保存同内容副本于 `docs/superpowers/specs/2026-10-17-conversational-evidence-desk-design.html`）。

## Global Constraints

- 默认观点1、观点2、临时查询三个会话，可新增会话；每个会话独立保存所选资料和核验时点。
- 三个默认会话预填原题 A、B、查询，初始不伪造模型回复；六份题目材料明确标为示例。
- 首版无登录、多用户协作、跨设备同步、向量数据库或后台定时爬取。
- 资料、原文件、会话与运行快照保存在当前浏览器；必须显示保存失败，支持导出／导入备份。
- API 密钥只存服务端，不能进入客户端、GitHub、运行记录、构建产物或公开源代码压缩包。
- 保留现有 `/api/config`、`/api/analyze` 与真实／人工参考模式的边界；不得在真实调用失败时返回预置结果。
- 每次核验最多20份资料，单份用于核验正文最多16000字，总计60000字，观点最多8000字；不得静默截断全文后声称完成整篇核验。
- 首版支持 TXT、Markdown、文字型 PDF、DOCX；扫描 PDF、加密或损坏文件明确报错，不承诺 OCR。
- 联网默认关闭；网页正文获取失败或只有摘要时，不作为已核验正文证据。发布日期未知的网页不得用于保证历史时点结论。
- 证据置信度显示高／中／低及原因，不能表示未经校准的事实概率，不能把检索排序分当作置信度。
- 版本提醒按指标生效；S1的380亿元和18%被S2修订，35%保持有效，环比-7%仅旧版披露；历史查询排除后发资料。
- 前文仅提供问题背景；模型结论、改写和联网引用仍需检查并供人工复核，不输出内部思维链。

## Review Focus

1. 回复等待中切换／删除会话、更新资料：回复必须绑定原会话与原快照，不能出现在另一个会话，删除后不能复活。
2. 浏览器存储配额不足、拒绝写入、备份损坏或导入ID冲突：明确未保存，失败导入不能破坏当前资料。
3. 同名公司、不同统计期、同一指标不同单位或仅相关的网页：不能被误识别为明确修订。
4. 网页只有摘要、日期未知、重定向到非正文或含恶意指令：不假造全文／日期，不将正文作为系统指令执行。
5. 上传成功但正文为空、解析错误、内容超限或文件名含HTML：明确解析结果与处理范围，界面按纯文本显示。

以上分别由任务1、1、5、3、2的测试与任务7浏览器验收覆盖。

## File Structure

保留 `src/data.mjs`、`src/reference.mjs`、`src/core.mjs` 的现有职责；新增文件按能力分开，避免把全部逻辑堆入 `public/app.js`。

| 文件 | 职责 |
| --- | --- |
| `src/workspace.mjs` | 会话、知识库领域操作，快照与备份校验，纯函数 |
| `public/modules/storage.mjs` | IndexedDB事务与Blob持久化 |
| `public/modules/files.mjs` | 文件解析、页码／段落定位与长度检查 |
| `public/modules/client.mjs` | 同源／Pages后端请求与中止 |
| `public/modules/chat-view.mjs` | 会话和结构化回复渲染、引用跳转与复核 |
| `public/modules/library-view.mjs` | 知识库、选材、导入和原文详情渲染 |
| `public/app.js` | 启动、视图切换与事件协调，不承载模型业务逻辑 |
| `src/model.mjs`、`src/chat.mjs` | 共用受控模型调用与对话上下文校验 |
| `src/search.mjs`、`src/confidence.mjs` | 官方Search／Fetch适配与证据等级规则 |
| `src/versions.mjs` | 候选版本关系的结构、引用与时点校验 |
| `src/api.mjs` | 路由、跨域与访问码边界 |
| `scripts/build-client.mjs` | 打包浏览器模块与解析worker |
| `scripts/run-evaluation.mjs` | 保存真实模型及检索验收记录，脱敏输出 |
| `tests/{workspace,files,chat,search,versions,build}.test.mjs` | 新增能力测试；既有核心与API测试保留 |

共同数据约定：`Document`沿用S1—S999唯一编号并扩展`origin: sample|upload|web`、`revision`、`publishedAt: string|null`、`segments: [{text,page?,paragraph?}]`、`url?`、`retrievedAt?`、`fileId?`、`reviewDueAt?`。正文与元信息来源均可追溯，不从文件名猜测。

`Session`包含`id,title,task,draft,asOf,selectedSourceIds,webEnabled,messages,pendingRunId`。`Message`包含`id,role,text,createdAt,snapshot?,result?,error?`。`Workspace`包含`schemaVersion:2,activeSessionId,documents,sessions,versionEdges`。密钥和体验码不进入Workspace或备份。

---

### Task 1: 持久化的会话与知识库基础

**Files:** Create `src/workspace.mjs`, `public/modules/storage.mjs`, `tests/workspace.test.mjs`; consume `src/data.mjs`.

**Interfaces:**
- `createWorkspace(sources,examples): Workspace`，仅首次初始化示例；不因刷新补回用户已删除的数据。
- `createSession(workspace,{title?}): Workspace`，新增会话不默认选资料。
- `updateSession(workspace,id,patch): Workspace`；`removeSession(workspace,id): Workspace`。
- `captureRun(workspace,sessionId,{runId,message}): RunSnapshot`，复制原会话当前观点、时点、选中资料和版本号；未知日期资料返回排除原因。
- `attachReply(workspace,{sessionId,runId,snapshot,result}): Workspace`，只绑定原会话，已删除则忽略；当前资料变化时结果仍以原快照展示并标需重新核验。
- `serializeBackup(workspace,files): Backup`／`validateBackup(raw): Backup`，校验通过后才允许替换，禁止密钥字段。
- `openStorage(): Promise<{load(),save(workspace),putFile(id,blob),getFile(id),exportBackup(),importBackup(backup)}>`；保存失败由调用方显示“更改尚未保存”。

- [ ] **Step 1:** 写失败测试：默认标题恰为观点1／观点2／临时查询，观点分别等于A/B/Q；默认6份示例；新增会话选择为`[]`；修改一个会话不改变另一个；快照在修改原资料后仍保留旧文本。
- [ ] **Step 2:** 写失败测试：等待时切换会话后`attachReply`只更新原ID；删除原会话后回复不复活；备份含重复资料ID、非法日期或凭证字段时拒绝；存储适配器写入失败会抛出可呈现错误，原数据仍在。
- [ ] **Step 3:** 运行 `node --test tests/workspace.test.mjs`，确认失败来自尚未实现的模块／行为。
- [ ] **Step 4:** 实现纯函数与IndexedDB适配，Workspace和原文件用同一数据库的独立object store；导入采用单事务替换，初始化／恢复失败不默默重置用户库。
- [ ] **Step 5:** 同一测试通过后提交本任务文件：`git commit -m "feat: persist independent research sessions and library"`。浏览器刷新与配额失败交互由任务6/7验收。

### Task 2: 真实上传解析与范围说明

**Files:** Create `public/modules/files.mjs`, `tests/files.test.mjs`, `tests/fixtures/material.{txt,md,pdf,docx}`; modify `package.json`, generate lockfile.

**Interfaces:**
- `parseFile(file,{purpose:'opinion'|'evidence'}): Promise<{name,mime,text,segments,warnings,original:Blob}>`。
- `prepareSource(parsed,metadata,{excerpt?}): Document`；未知元信息保持未知。超限时拒绝用于整篇核验，可让用户明确选定页／段形成资料选段，保存选段范围与原文件关系。
- TXT/MD明确支持UTF-8；无法可靠解码时提示转成UTF-8，不展示乱码后宣称成功。PDF用`getTextContent`逐页提取，DOCX用`extractRawText`，按纯文本渲染。

- [ ] **Step 1:** 写测试：TXT中文与`<script>`字样原样作为文本；PDF含“380 to 360”的正文出现在对应页；DOCX正文可提取；空正文、损坏包、不支持扩展名、超过10MiB文件、超长观点都报明确错误。
- [ ] **Step 2:** 运行 `node --test tests/files.test.mjs` 验证失败。随后从官方npm包安装并锁定`pdfjs-dist`、`mammoth`与构建依赖`esbuild`，核对引擎要求，更新启动说明。
- [ ] **Step 3:** 实现解析与资源释放；PDF worker随构建部署。样例PDF／DOCX只作为解析测试，不混入产品预置资料；不执行文档里的HTML、链接或指令。
- [ ] **Step 4:** 运行解析测试直到通过，保留PDF页码／DOCX段落定位；用实际题目PDF在浏览器检查中文提取。扫描／加密PDF在浏览器给出明确限制，不能返回虚构正文。
- [ ] **Step 5:** 提交本任务文件：`git commit -m "feat: parse and preview uploaded evidence files"`。

### Task 3: 可追溯网页检索与证据等级

**Files:** Create `src/search.mjs`, `src/confidence.mjs`, `tests/search.test.mjs`; modify `src/api.mjs`, `.env.example`（仅字段说明）。

**Interfaces:**
- `searchWeb({query,count=5},env,transport=fetch): Promise<SearchCandidate[]>`，适配官方`POST https://api.deepseek.com/v1/tools/search`，`need_content:true`，查询限制128字，最多5条。
- `fetchWebPage({url},env,transport=fetch): Promise<{url,title,content,retrievedAt}>`，接受公开HTTPS URL，调用官方`/v1/tools/fetch`；拒绝含凭证、回环或私网地址。产品入口由用户选择实际搜索候选；服务端不信任客户端自行声明的来源身份，也不在本地服务抓取用户给出的内网URL。
- `assessEvidence({hasFullText,quoteVerified,publishedAt,asOf,primaryConfirmed,anonymous,hasConflict}): {level:'high'|'medium'|'low'|'unavailable',reasons:string[],eligible:boolean}`。原文／引用缺失不合格；未知／未来日期排除历史核验；原始来源由用户确认后才可评高，其余合格全文默认中；匿名或冲突降为低。检索排名单独存储，不冒充置信度。
- `POST /api/search {query,asOf}`返回候选；`POST /api/fetch {url,candidate}`返回正文。两条路线复用访问码、允许来源、限长、超时与脱敏错误。

- [ ] **Step 1:** 写测试：有正文与只有snippet分别合格／不合格；无结果返回空列表；日期不明不捏造；401/402/429、超时与非JSON返回明确错误且不含key；拒绝私网URL；网页恶意指令保持普通数据。
- [ ] **Step 2:** 写等级测试：`quoteVerified:false`为unavailable；全文＋已确认原始来源＋已知适用日期＋无冲突为high；二手为medium；匿名／冲突为low；future与null日期的`eligible:false`。
- [ ] **Step 3:** 运行 `node --test tests/search.test.mjs` 确认失败；实现官方适配和等级函数。正文失败可保留候选线索，但不生成资料正文。
- [ ] **Step 4:** 同一测试通过；用现有本地私密配置做一次实际官方文档主题检索及正文抓取，保存脱敏记录，核对原链接和正文确实存在。若账号不支持，保留明确错误，不能声称已实现真实搜索。
- [ ] **Step 5:** 提交本任务文件：`git commit -m "feat: retrieve traceable web sources with evidence grades"`。

### Task 4: 连续对话与真实核验

**Files:** Create `src/model.mjs`, `src/chat.mjs`, `tests/chat.test.mjs`; modify `src/api.mjs`, `src/prompt.mjs`, `src/core.mjs` only where required.

**Interfaces:**
- `callModel({messages,responseFormat},env,transport): Promise<{content,usage,requestId}>`，从现有API抽出共用调用，保留超时、输出上限、脱敏和严格JSON处理。
- `analyzeConversation({message,task,focusText,history,sources,asOf,mode},env,transport): Promise<ChatResult>`；`task:verify|query|followup`，history最多12条、合计12000字，仅当前会话，作为不可信背景。
- `ChatResult`沿用现有`summary,answer,rewrite,claims,warnings,input,provenance`，增加`replyKind:verify|query|followup`和`focusText`。followup的事实与解释同样附claims及原文依据，不额外输出一段绕过校验的自由事实答案。
- `POST /api/chat`使用上述接口；保留`/api/analyze`测试及人工参考三例。人工参考不支持任意追问，必须明确要求连接真实模型。

- [ ] **Step 1:** 写测试：不同history输入仅含对应会话；被取消勾选资料不能从旧回答重新进入证据；未来资料排除；用户材料中的system文本不会成为模型消息角色；引用伪造仍降级／拒绝。
- [ ] **Step 2:** 写跟进场景测试：消息“按建议重写”保留同会话`focusText`；解释问题返回可追溯claims；超长history拒绝；真实失败不回退参考。运行 `node --test tests/chat.test.mjs tests/api.test.mjs tests/core.test.mjs`，先确认新行为失败。
- [ ] **Step 3:** 实现共用调用和上下文输入。完善提示词区分“机构确实作出预测”与“预测将实现”；禁止将旧版独有指标拼接为新版同口径数值。改写须引用已核验事实，保留预测和匿名信息性质，界面明确采用前复核。
- [ ] **Step 4:** 上述测试通过后实际运行A/B/Q与一次追问，检查B的预测转述得到支持、A的建议改写对环比有明确旧版限定或不采用该数值。真实语义验收记录不能用提示词字符串断言或测试上游响应冒充。
- [ ] **Step 5:** 提交本任务文件：`git commit -m "feat: support grounded multi-turn evidence review"`。

### Task 5: 字段版本关系与受影响会话

**Files:** Create `src/versions.mjs`, `tests/versions.test.mjs`; extend `src/workspace.mjs`, `src/api.mjs`, `src/data.mjs` with clearly labeled sample annotations.

**Interfaces:**
- `detectVersionCandidates(documents,env,transport): Promise<VersionEdge[]>`：`POST /api/versions`调用真实模型对有新入库资料的候选集合识别，保留旧／新原文依据，不假装所有资料已被全网更新。
- `validateVersionEdges(raw,documents): VersionEdge[]`：边包含`oldId,newId,entity,period,metric,oldValue,newValue,oldQuote,newQuote,effectiveAt,kind:revised|unchanged|possible,review:pending|confirmed|dismissed,origin:model|sample-annotation`。两端必须存在、引用匹配，明确修订需有可比来源／期间／单位与修订原文；不满足条件只能possible或拒绝。
- `documentVersionStatus(documentId,edges,{asOf}): {items,needsReview}`；`affectedSessions(workspace,edges): {sessionId,messageId,metrics}[]`，仅对实际引用相关指标、且修订在会话时点前生效的回答提醒。
- `setVersionReview(workspace,edgeId,review): Workspace`，人工确认／忽略可追溯。模型识别结果展示“AI识别，待复核”，不改写原正文。示例人工标注与真实识别明确区分。

- [ ] **Step 1:** 写测试：S1/S2销售额与同比为revised，35%为unchanged，环比未重申；截至4月10日不应用4月20日修订；无明确修订关系为possible；不同公司／年份／单位不能判明确修订；无效quote拒绝。
- [ ] **Step 2:** 写提醒测试：只引用35%的会话不提示数据被修订；引用18%且时点4月25日的会话提示；历史时点4月10日不提示要求采纳后发值；设置复核日期到期不把历史事实标假。
- [ ] **Step 3:** 运行 `node --test tests/versions.test.mjs tests/workspace.test.mjs` 确认新行为失败，实现候选识别、引用校验与关系展示数据。
- [ ] **Step 4:** 同一测试通过，再上传一份改写措辞的新修订资料真实验证自动识别，核对关系与引文；冲突不自动覆盖旧值。
- [ ] **Step 5:** 提交本任务文件：`git commit -m "feat: track field revisions and affected conversations"`。

### Task 6: 完整对话工作台与知识库界面

**Files:** Replace `public/index.html`, `public/style.css`, reorganize `public/app.js`; create `public/modules/{client,chat-view,library-view}.mjs`, `scripts/build-client.mjs`; modify `server.mjs`, scripts/build-pages.mjs, scripts/build-single.mjs, scripts/build.mjs, src/pages-client.mjs; add `tests/build.test.mjs` and update `tests/pages.test.mjs` for actual module build.

**Interfaces:**
- `createClient({apiBase='',accessCode,transport=fetch}): {config(),chat(body,signal),search(body,signal),fetchPage(body,signal),versions(body,signal),analyze(body,signal)}`。无后端的Pages仅允许明确人工参考，不将搜索与追问伪装成功。
- `renderChat({workspace,session,connection,onAction}): void`；`renderLibrary({documents,edges,selectedIds,onAction}): void`。回调由app统一更新Workspace并持久化，不在渲染函数偷偷发送模型请求。
- `buildClient({outDir,apiBase}): Promise<BuildManifest>`产生应用模块、PDF worker与必要静态资源；各部署构建复用它。PUBLIC_API_BASE仅是非秘密HTTPS后端URL；禁止将整个process.env注入前端。

- [ ] **Step 1:** 写构建测试：所有HTML／worker资源可在`/evidence-desk/`子路径加载，已知测试密钥不会出现在任何产物；无后端时新增API返回清晰错误。先运行 `node --test tests/build.test.mjs tests/pages.test.mjs` 确认失败。
- [ ] **Step 2:** 保留现有绿色专业风格，使用UI技能检索指导排版／焦点／加载反馈；实现左侧会话、中间对话、可收起资料侧栏与独立知识库。窄屏将导航和资料做抽屉，不水平挤压正文。
- [ ] **Step 3:** 接通任务1—5接口。上传先预览再入库；缺失日期显式补充；搜索先展示候选和原文状态；原文可定位页／段；所有模型请求有等待、停止等待、失败和重试反馈。
- [ ] **Step 4:** 实现重命名／新增／删除会话、资料筛选／移除／原文、原文件下载、明确的本机保存状态、备份导出／导入、结果导出和复核。停止等待不宣称上游一定已停止计费。
- [ ] **Step 5:** 更新构建与本地服务路由，确保esbuild打包而非旧字符串拼接。单文件发布入口可引用同目录worker等附属资源；GitHub上传包必须包含它们，不再承诺一个HTML独立完成PDF解析。
- [ ] **Step 6:** 构建测试与原有核心/API测试通过；浏览器验证三会话切换、上传、搜索、追问、版本提醒、刷新保留、键盘焦点与窄屏布局后提交：`git commit -m "feat: deliver conversational research workspace and library"`。

### Task 7: 集成验收、说明与发布

**Files:** Create `scripts/run-evaluation.mjs`, `records/v2-evaluation.json`; update `README.md`, `GITHUB部署说明.md`, `public/design.html`, relevant builds and deployment records.

**Interfaces:**
- `node --env-file=.env scripts/run-evaluation.mjs --live`执行A/B/Q、A改12%、查询不选S2、查询时点4月10日与一次连续追问；输出`records/live-v2-*.json`并记录人工检查项，不输出key。
- 真实搜索／抓取与版本识别另存实际运行记录，区分模型实测、程序测试及人工标注。

- [ ] **Step 1:** 运行全部 `npm test`、浏览器与Worker构建、Pages与发布包构建，确认产物子路径、worker和CORS一致。仅在新增失败或修改后重复相应检查。
- [ ] **Step 2:** 执行真实评估：Q应360亿元／12%；去掉S2为初步380亿元／18%；4月10日排除S2/S5；A改12%后首项支持；B不因转述预测被判错误；环比不拼接进修订值。人工检查语义和改写，记录未解决问题。
- [ ] **Step 3:** 浏览器端到端验收：在不同会话分别选材和追问；请求中切换／删除会话；真实上传PDF／DOCX／TXT；打开引用；搜索正文成功与失败；添加新修订并查看受影响会话；导出、刷新、导入、删除与保存失败提示。保存必要截图，不因单个截图就宣称所有路径通过。
- [ ] **Step 4:** 使用独立代码审查技能审查本次diff与验收记录，修复实际发现的问题后跑受影响检查。不得把旧版已有未提交改动或密钥误放入新提交。
- [ ] **Step 5:** 公网后端沿用已创建的Sites资产，先核对其当前访问范围；通过平台环境变量安全配置密钥与体验码、允许GitHub origin，部署前核对请求边界。面向评审匿名访问需实际验证；任何额外平台批准按原生工具处理，不用把key贴入聊天。
- [ ] **Step 6:** 将PUBLIC_API_BASE指向真实后端，构建并更新用户指定GitHub仓库的发布文件。使用未登录访问验证页面、真实核验、搜索、上传解析及CORS；未完成的能力保持明确状态，不用参考结果冒充真实调用。
- [ ] **Step 7:** 更新设计说明、已测能力和限制，生成不含`.env`、`.git`、私人云资产标识及凭证的源码包，提供实际部署链接、本地入口与截图。完成前核对交付物无秘密且新旧版本标识一致。

## Execution recommendation

建议由主代理在当前对话按任务顺序执行，最后进行一次独立审查。会话快照、资料结构、引用校验与部署构建的接口关联较紧；顺序执行便于保持一致。另一选项为逐任务分派独立实施与审查，审查更频繁，但上下文与调用成本更高。此计划写入后等待用户审阅并选择方式，再开始产品实现。

## Plan self-review

- 方案六节均映射到任务1—7；原题三例、真实上传、联网原文、置信度、字段修订、历史时点、会话持久化与公网路径均有验收。
- 所有跨任务接口使用同一Workspace／Document／Session／VersionEdge数据名称；unknown日期不伪造为导入时间。
- 五项Review Focus均分配到具体任务；语义质量用真实调用与人工审阅，引用程序测试不能替代它。
- 没有引入未要求的登录、数据库服务、多人权限或后台定时任务。
