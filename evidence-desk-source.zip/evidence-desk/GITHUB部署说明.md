# GitHub Pages 与真实 AI 后端

前端：https://yling110500.github.io/evidence-desk/

Pages只能运行静态页面。真实模型、搜索、抓取和修订比较通过独立后端 `/api` 调用。后端配置 `LLM_API_KEY`、`LLM_BASE_URL`、`LLM_MODEL`、`LLM_JSON_MODE`、`DEMO_ACCESS_CODE` 和 `ALLOWED_ORIGINS`（含 https://yling110500.github.io）。体验码单独交付，不能把模型密钥写入网页、README或仓库。

## 构建静态发布文件

```sh
PUBLIC_API_BASE=https://你的后端域名 npm run build:pages
node scripts/build-single.mjs
```

将 `github-publish/` 中的完整文件上传至仓库根目录，提交到Pages启用的分支。包括 `index.html`、CSS、模块分块、PDF worker、设计说明和 `.nojekyll`，不能只替换HTML。Pages设置使用main分支根目录。

核验设置中显示「真实AI」，填写体验码，运行临时查询应得360亿元、12%。再移除S2或将核验时点设为4月10日，应使用380亿元、18%的旧版初步统计。检查文件上传和PDF worker；移动端也应可打开会话与资料面板。

## 后端

`npm run build` 生成 `dist/server/index.js` Worker和部署元数据。密钥只在托管平台的运行环境中设置，环境配置变化后需重新部署。CORS限制允许的前端来源，真实付费接口检查体验码；人工参考模式无需体验码。

体验码不是多用户权限或完整限流。演示结束后可在后端轮换体验码或暂停模型调用。浏览器知识库保存在本机，跨设备需手动导入备份。
