# GitHub 部署说明

GitHub Pages公开访问不需要评审登录ChatGPT。Pages仅托管静态文件，不能运行本项目Node后端；真实AI核验需单独托管后端。原题参考模式现在可完全在浏览器运行，始终标注为人工参考。

## 代码仓库与前端

1. 把本目录的源码放到目标GitHub仓库根目录，不上传`.env`、`.git`、`dist`、`pages`或私有凭证。
2. 仓库默认分支设为`main`。如使用其他分支，调整`.github/workflows/pages.yml`的`branches`。
3. 在仓库 Settings → Pages → Build and deployment 中选择 GitHub Actions。
4. 推送到main，或者在Actions页手动运行 Deploy Evidence Desk to GitHub Pages。
5. 等待构建和部署成功，从工作流的部署输出取得真实地址。不能在部署成功前把预计URL当作已上线链接。

工作流先运行全部测试，再执行`npm run build:pages`生成`pages/`，只发布该静态目录。静态资源使用相对路径，支持`https://账号.github.io/仓库名/`这样的项目路径。

若账号尚未向当前GitHub连接授权目标仓库，需要先在GitHub连接设置中授权。目标仓库已确认为公开仓库 yling110500/evidence-desk；实际发布状态以工作流和网页访问验证为准。

## 连接真实AI后端

把完整Node服务部署到支持Node进程的服务，或使用现有Worker构建产物部署到合适平台。配置后端的`LLM_API_URL`、`LLM_MODEL`、`LLM_API_KEY`；如公网开放真实调用，设置`DEMO_ACCESS_CODE`。

后端设置`ALLOWED_ORIGINS=https://你的账号.github.io`，包含origin即可，不含仓库路径。该设置限制浏览器跨域来源，不能代替体验码、额度或正式限流。

在GitHub仓库 Settings → Secrets and variables → Actions → Variables 添加`PUBLIC_API_BASE`，值为后端HTTPS地址，不包含末尾`/api`。例如后端为`https://api.example.com`，前端会请求`https://api.example.com/api/config`和`/api/analyze`。**这是公开地址，不是API密钥。模型密钥只能放在后端环境变量里。**

设置该变量后重新运行Pages工作流。前端会使用后端接口；后端失败时明确提示，不会悄悄回到人工参考。没有配置`PUBLIC_API_BASE`时，Pages提供原题三例的参考演示，不声称支持真实模型生成。

## 验收

- 未登录浏览器能打开Pages地址。
- 三例可运行，模式标记与结果来源一致。
- 编辑观点或材料后，参考模式不返回旧答案。
- 接入后端后验证A/B/临时查询及变体，并检查原文引用与时间口径。
- 检查网页请求与公开产物中不存在模型密钥。
- 提交前保存三个案例实际运行的结果截图和记录。

官方说明：[GitHub Pages简介](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages)、[自定义部署工作流](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages)。
