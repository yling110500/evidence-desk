import {mkdir,readFile,writeFile,copyFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=new URL('../',import.meta.url);
export async function buildPages(outputPath,apiBase=''){
 if(apiBase){const u=new URL(apiBase);if(u.username||u.password||u.search||u.hash||u.protocol!=='https:')throw new Error('PUBLIC_API_BASE must be an HTTPS backend URL without credentials, query or fragment.');}
 const out=resolve(outputPath);await mkdir(resolve(out,'lib'),{recursive:true});
 for(const file of ['core','data','reference','prompt','api','pages-client'])await copyFile(new URL(`src/${file}.mjs`,root),resolve(out,`lib/${file}.mjs`));
 for(const file of ['style.css','design.html'])await copyFile(new URL(`public/${file}`,root),resolve(out,file));
 let html=await readFile(new URL('public/index.html',root),'utf8');
 html=html.replaceAll('href="/style.css"','href="./style.css"').replaceAll('src="/app.js"','src="./app.js"').replaceAll('href="/design.html"','href="./design.html"');
 let app=await readFile(new URL('public/app.js',root),'utf8');
 if(!app.includes("fetch('/api/config')")||!app.includes("fetch('/api/analyze',"))throw new Error('App API integration changed; update the Pages builder before deployment.');
 app=`import {createPagesTransport} from './lib/pages-client.mjs';\nconst pagesRequest=createPagesTransport(${JSON.stringify(apiBase.replace(/\/$/,''))});\n`+app.replace("fetch('/api/config')","pagesRequest('config')").replace("fetch('/api/analyze',","pagesRequest('analyze',");
 await Promise.all([writeFile(resolve(out,'index.html'),html),writeFile(resolve(out,'app.js'),app),writeFile(resolve(out,'.nojekyll'),'')]);
 return out;
}
if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url){
 const out=await buildPages(fileURLToPath(new URL('../pages/',import.meta.url)),process.env.PUBLIC_API_BASE||'');
 console.log(`GitHub Pages artifact ready: ${out}`);
}
