import {cp,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {buildClient} from './build-client.mjs';
const root=new URL('../',import.meta.url);
export async function buildPages(outputPath,apiBase=''){
 const out=resolve(outputPath);await buildClient({outDir:out,apiBase,staticMode:true});
 await mkdir(resolve(out,'lib'),{recursive:true});await cp(new URL('src/',root),resolve(out,'lib'),{recursive:true});return out;
}
if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url){await buildPages(fileURLToPath(new URL('../pages/',import.meta.url)),process.env.PUBLIC_API_BASE||'');console.log('GitHub Pages assets built.');}
