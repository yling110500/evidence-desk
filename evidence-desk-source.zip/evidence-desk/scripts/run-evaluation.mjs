import {writeFile,mkdir} from 'node:fs/promises';import {analyzeConversation} from '../src/chat.mjs';import {SOURCES,EXAMPLES} from '../src/data.mjs';
if(!process.argv.includes('--live'))throw new Error('此脚本仅用于真实验收，请明确传入--live。');
await mkdir(new URL('../records/',import.meta.url),{recursive:true});
const sources=SOURCES.map(d=>({...d,origin:'sample'}));
const cases=[...['A','B','Q'].map(id=>({id,message:EXAMPLES[id].text,task:EXAMPLES[id].task})),{id:'A-edited',message:EXAMPLES.A.text.replace('18%','12%'),task:'verify'},{id:'Q-without-S2',message:EXAMPLES.Q.text,task:'query',sources:sources.filter(d=>d.id!=='S2')},{id:'Q-asof-0410',message:EXAMPLES.Q.text,task:'query',asOf:'2026-04-10'}];
const rows=[];let aResult;
async function run(c){try{const input={history:[],sources,asOf:'2026-04-25',mode:'live',...c};const result=await analyzeConversation(input,process.env);await writeFile(new URL(`../records/live-v2-eval-${c.id}.json`,import.meta.url),JSON.stringify(result,null,2));const checks={noProgramWarnings:result.warnings.length===0};
 if(c.id==='Q')checks.correctValues=result.answer.includes('360亿元')&&result.answer.includes('12%');
 if(['Q-without-S2','Q-asof-0410'].includes(c.id))checks.correctValues=result.answer.includes('380亿元')&&result.answer.includes('18%');
 if(c.id==='Q-asof-0410')checks.noFutureCitations=result.claims.every(x=>x.evidence.every(e=>!['S2','S5'].includes(e.sourceId)));
 if(c.id==='B')checks.forecastAttribution=result.claims.some(x=>x.text.includes('研究机构预测')&&x.status==='supported');
 if(c.id==='A-edited')checks.editedValueSupported=result.claims.some(x=>x.text.includes('同比增长12%')&&x.status==='supported');
 if(c.id==='A'){aResult=result;checks.noUnqualifiedOldQoQ=!result.rewrite.includes('7%')||/旧版|初步|未重申/.test(result.rewrite);checks.expectationBoundary=result.claims.some(x=>x.text.includes('第二季度产能利用率已经超过85%')&&x.status!=='supported');}
 const row={id:c.id,success:true,checks,runId:result.provenance.runId,seconds:result.provenance.elapsedMs/1000};rows.push(row);console.log(JSON.stringify(row));if(Object.values(checks).some(x=>!x))process.exitCode=1;
 }catch(e){rows.push({id:c.id,success:false,error:e.message});console.log(JSON.stringify(rows.at(-1)));process.exitCode=1;}}
for(let i=0;i<cases.length;i+=3)await Promise.all(cases.slice(i,i+3).map(run));
if(aResult)await run({id:'followup',message:'请解释为什么启明设备第二季度产能利用率已经超过85%的说法需要修改。',task:'followup',focusText:EXAMPLES.A.text,history:[{role:'assistant',text:aResult.summary}]});
await writeFile(new URL('../records/v2-evaluation.json',import.meta.url),JSON.stringify({createdAt:new Date().toISOString(),scope:'真实调用与关键行为初验，不代表全面准确率评估。原题样例已按PDF原文校正。',rows,manualReviewRequired:['修订适用性与预测表述','证据是否在语义上支持判断','改写是否引入无依据事实']},null,2));
