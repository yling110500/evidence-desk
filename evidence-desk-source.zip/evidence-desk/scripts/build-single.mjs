import {cp,mkdir,writeFile,rm,readdir} from 'node:fs/promises';import {fileURLToPath} from 'node:url';import {buildPages} from './build-pages.mjs';
const root=new URL('../',import.meta.url),target=fileURLToPath(new URL('github-publish/',root));
await rm(target,{recursive:true,force:true});await mkdir(target,{recursive:true});const out=await buildPages(fileURLToPath(new URL('pages/',root)),process.env.PUBLIC_API_BASE||'');for(const e of await readdir(out,{withFileTypes:true}))if(e.isFile())await cp(out+'/'+e.name,target+'/'+e.name);
await writeFile(new URL('github-publish/README.md',root),'# 证研 · 投研证据工作台\n\n公开入口：https://yling110500.github.io/evidence-desk/\n\n包含对话、浏览器知识库、真实文件解析。真实AI及搜索须连接独立服务端。所有同目录JS模块与PDF worker都必须一并上传。源代码压缩包不含密钥。\n');console.log('GitHub upload bundle ready.');
