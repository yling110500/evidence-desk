import {readFile,mkdir,writeFile,copyFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {buildPages} from './build-pages.mjs';

// A self-contained entrypoint can be uploaded through GitHub's standard web UI.
const root=new URL('../',import.meta.url);
const pages=await buildPages(fileURLToPath(new URL('pages/',root)),process.env.PUBLIC_API_BASE||'');
const target=fileURLToPath(new URL('github-publish/',root));
await mkdir(target,{recursive:true});
const parts=[];
for(const name of ['data','core','reference','prompt','api','pages-client']){
 const code=await readFile(resolve(pages,`lib/${name}.mjs`),'utf8');
 parts.push(code.replace(/^import .+;\n/gm,'').replace(/^export /gm,''));
}
parts.push((await readFile(resolve(pages,'app.js'),'utf8')).replace(/^import .+;\n/gm,''));
const js=parts.join('\n').replace(/<\/script/gi,'<\\/script');
const css=await readFile(resolve(pages,'style.css'),'utf8');
const html=(await readFile(resolve(pages,'index.html'),'utf8'))
 .replace('<link rel="stylesheet" href="./style.css">',`<style>${css}</style>`)
 .replace('<script type="module" src="./app.js"></script>',`<script type="module">${js}</script>`);
await writeFile(resolve(target,'index.html'),html);
await writeFile(resolve(target,'.nojekyll'),'');
await copyFile(resolve(pages,'design.html'),resolve(target,'design.html'));
await writeFile(resolve(target,'README.md'),`# 证研 · 投研观点证据核验助手\n\n公开体验地址：https://yling110500.github.io/evidence-desk/\n\n面试演示作品，材料均为虚构。当前为明确标注的人工参考演示，提供观点A、观点B和临时查询三个案例。真实AI核验还需独立后端与模型凭证。\n\n- index.html：可直接由GitHub Pages托管的完整前端，不含密钥。\n- design.html：产品设计思路文档。\n- evidence-desk-source.zip：完整源码、后端接口、测试与部署说明，不含凭证或私人云端资产标识。\n\nPages使用main分支根目录发布。源码解压后可用Node.js 22.9+运行；18项自动化测试通过。\n\n更新页面：在源码目录运行 node scripts/build-single.mjs，将github-publish中的index.html和design.html上传到仓库。设置PUBLIC_API_BASE后可构建连接真实后端的版本，密钥只能留在后端。\n`);
await writeFile(resolve(target,'embedded-app.mjs'),js);
console.log(`Single-file Pages entry ready: ${target}`);
