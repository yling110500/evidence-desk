import {build} from 'esbuild';import {mkdir,copyFile,readFile,writeFile,readdir} from 'node:fs/promises';import {resolve} from 'node:path';import {fileURLToPath,pathToFileURL} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
export async function buildClient({outDir,apiBase='',staticMode=false}){
 if(apiBase){const u=new URL(apiBase);if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash)throw new Error('后端地址须为无凭证的HTTPS地址。');}
 const out=resolve(outDir);await mkdir(out,{recursive:true});
 await build({entryPoints:[resolve(root,'public/app.js')],outdir:out,bundle:true,splitting:true,format:'esm',platform:'browser',target:['es2022'],minify:true,charset:'utf8',define:{__API_BASE__:JSON.stringify(apiBase.replace(/\/$/,'')),__STATIC_MODE__:JSON.stringify(staticMode)},logLevel:'silent'});
 for(const f of ['index.html','style.css','design.html'])await copyFile(resolve(root,'public',f),resolve(out,f));
 await copyFile(resolve(root,'node_modules/pdfjs-dist/legacy/build/pdf.worker.min.mjs'),resolve(out,'pdf.worker.min.mjs'));
 await writeFile(resolve(out,'.nojekyll'),'');
 return {directory:out,files:await readdir(out)};
}
if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url){await buildClient({outDir:resolve(root,'dist/client'),apiBase:process.env.PUBLIC_API_BASE||''});console.log('Browser assets built.');}
