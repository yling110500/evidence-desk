import {mkdir,writeFile} from 'node:fs/promises';
import {handleApi} from '../src/api.mjs';
import {SOURCES,EXAMPLES} from '../src/data.mjs';
const mode=process.argv.includes('--live')?'live':'reference';
await mkdir(new URL('../records/',import.meta.url),{recursive:true});
let failed=false;
for(const id of ['A','B','Q']){
 const input={task:EXAMPLES[id].task,text:EXAMPLES[id].text,asOf:'2026-04-25',sources:SOURCES,mode};
 const response=await handleApi(new Request('http://localhost/api/analyze',{method:'POST',headers:{'Content-Type':'application/json',...(process.env.DEMO_ACCESS_CODE?{Authorization:`Bearer ${process.env.DEMO_ACCESS_CODE}`}:{})},body:JSON.stringify(input)}),process.env);
 const record=await response.json();
 if(response.status!==200){console.error(`Case ${id}: failed — ${record.error}`);failed=true;continue;}
 // This records system execution, not evidence that a model produced reference fixtures.
 await writeFile(new URL(`../records/case-${id}-${mode}.json`,import.meta.url),JSON.stringify(record,null,2));
 console.log(`Case ${id}: ${mode}, ${record.claims.length} claims, ${record.warnings.length} citation warnings, ${record.provenance.runId}`);
}
if(failed)process.exitCode=1;
