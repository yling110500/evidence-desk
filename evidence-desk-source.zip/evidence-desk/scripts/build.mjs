import {readFile,mkdir,writeFile} from 'node:fs/promises';
const root=new URL('../',import.meta.url);
const chunks=[];
for(const file of ['data','core','reference','prompt','api']){
 const src=await readFile(new URL(`src/${file}.mjs`,root),'utf8');
 chunks.push(src.replace(/^import .+;\n/gm,'').replace(/^export /gm,''));
}
const assets={};
for(const [path,file,type] of [['/','index.html','text/html'],['/style.css','style.css','text/css'],['/app.js','app.js','text/javascript'],['/design.html','design.html','text/html']]){
 assets[path]={type,body:await readFile(new URL(`public/${file}`,root),'utf8')};
}
const worker=chunks.join('\n')+`\nconst ASSETS=${JSON.stringify(assets)};\nexport default {async fetch(request,env){const path=new URL(request.url).pathname;if(path.startsWith('/api/'))return handleApi(request,env);const asset=ASSETS[path];if(!asset||!['GET','HEAD'].includes(request.method))return new Response('Not found',{status:404});return new Response(request.method==='HEAD'?null:asset.body,{headers:{'Content-Type':asset.type+'; charset=utf-8','X-Content-Type-Options':'nosniff','Cache-Control':'no-cache','Referrer-Policy':'same-origin'}});}};\n`;
await mkdir(new URL('dist/server/',root),{recursive:true});await mkdir(new URL('dist/.openai/',root),{recursive:true});
await writeFile(new URL('dist/server/index.js',root),worker);
await writeFile(new URL('dist/.openai/hosting.json',root),await readFile(new URL('.openai/hosting.json',root)));
const mod=await import(`data:text/javascript;base64,${Buffer.from(worker).toString('base64')}`);
const home=await mod.default.fetch(new Request('https://example.test/'),{});
if(home.status!==200||!(await home.text()).includes('投研观点核验'))throw new Error('Worker home validation failed');
console.log('Worker build verified: home page and default.fetch available.');
