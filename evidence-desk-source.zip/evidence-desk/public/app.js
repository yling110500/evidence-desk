const $=s=>document.querySelector(s);
const state={config:null,sources:[],examples:{},task:'verify',example:null,result:null,reviews:{},editing:null,controller:null,epoch:0,filter:'all'};
const paths={layers:'M12 3 2 8l10 5 10-5-10-5ZM2 12l10 5 10-5M2 16l10 5 10-5',book:'M4 3h6a3 3 0 0 1 3 3v15a4 4 0 0 0-4-3H3V3Zm9 3a3 3 0 0 1 3-3h5v15h-5a3 3 0 0 0-3 3',external:'M14 3h7v7M21 3l-9 9M10 5H4v15h15v-6',settings:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8ZM9 3h6l1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1 1-3Z',shield:'M12 3 4 6v6c0 5 8 9 8 9s8-4 8-9V6l-8-3Zm-4 9 3 3 5-6',checkfile:'M14 2H5v20h14V7l-5-5Zm0 0v6h5M8 14l3 3 5-6',search:'M10 3a7 7 0 1 0 0 14 7 7 0 0 0 0-14Zm5 12 6 6',plus:'M12 4v16M4 12h16',arrow:'M4 12h16m-6-6 6 6-6 6',chevron:'m9 5 7 7-7 7',spark:'m12 2 3 7 7 3-7 3-3 7-3-7-7-3 7-3 3-7Z',download:'M12 3v12m-5-5 5 5 5-5M4 15v6h16v-6',info:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm0 7v7m0-11v1',close:'m6 6 12 12M6 18 18 6',check:'m5 12 4 4L19 6',link:'M10 14 14 10M8 16l-1 1a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0m0 2 1-1a4 4 0 0 1 6 6l-5 5a4 4 0 0 1-6 0',warning:'m12 3 10 18H2L12 3Zm0 6v5m0 3v1',circle:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z'};
function icon(name){return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name]||paths.info}"></path></svg>`;}
function paintIcons(root=document){root.querySelectorAll('[data-icon]').forEach(el=>el.replaceWith(new DOMParser().parseFromString(icon(el.dataset.icon),'text/html').body.firstChild));}
const escape=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const show=(el,visible)=>el.classList.toggle('hidden',!visible);
const statusNames={supported:'有证据支持',contradicted:'与材料不符',insufficient:'证据不足',conditional:'推断需限定'};
const statusIcons={supported:'check',contradicted:'close',insufficient:'warning',conditional:'info'};
function toast(text){$('#toast').textContent=text;show($('#toast'),true);clearTimeout(toast.timer);toast.timer=setTimeout(()=>show($('#toast'),false),2600);}
function notice(text){$('#notice').textContent=text;show($('#notice'),!!text);}
function setBusy(busy){$('#run').disabled=busy;$('#results-region').setAttribute('aria-busy',String(busy));show($('#loading'),busy);show($('#cancel'),busy);if(busy){show($('#empty'),false);show($('#result'),false);}else{show($('#empty'),!state.result);show($('#result'),!!state.result);}}
function invalidate(){state.epoch++;state.controller?.abort();state.controller=null;state.result=null;state.reviews={};state.filter='all';$('#result').replaceChildren();$('#export').disabled=true;$('#result-subtitle').textContent='输入已更新，重新核验后查看结果';setBusy(false);notice('');}
function updateCount(){$('#char-count').textContent=`${$('#viewpoint').value.length} / 8000`;}
function setTask(task){state.task=task;$('#tab-verify').classList.toggle('selected',task==='verify');$('#tab-query').classList.toggle('selected',task==='query');$('#tab-verify').setAttribute('aria-selected',String(task==='verify'));$('#tab-query').setAttribute('aria-selected',String(task==='query'));$('#input-title').textContent=task==='verify'?'待核验观点':'研究问题';$('#viewpoint').placeholder=task==='verify'?'粘贴需要核验的观点，系统将逐项匹配材料中的证据。':'输入需要依据现有材料回答的问题。';}
function renderSources(){
 const date=$('#asof').value;
 $('#source-list').innerHTML=state.sources.map(s=>`<div class="source-row ${s.publishedAt>date?'future':''}"><input type="checkbox" data-select-source="${s.id}" aria-label="选择${escape(s.title)}" ${s.selected?'checked':''}><button class="source-open" data-open-source="${s.id}"><span class="source-no">${s.id}</span><span class="source-info"><strong>${escape(s.title)}</strong><small>${escape(s.publishedAt)} · ${escape(s.publisher)}</small></span></button><span class="source-kind">${s.publishedAt>date?'时点之后':escape(s.kind||'自定义')}</span></div>`).join('');
 const selected=state.sources.filter(s=>s.selected),eligible=selected.filter(s=>s.publishedAt<=date);
 $('#source-count').textContent=selected.length;$('#eligible-count').textContent=`${eligible.length} 份材料可用${selected.length>eligible.length?` · ${selected.length-eligible.length} 份晚于时点`:''}`;
}
function loadExample(id){invalidate();const ex=state.examples[id];state.example=id;setTask(ex.task);$('#viewpoint').value=ex.text;$('#asof').value='2026-04-25';document.querySelectorAll('[data-example]').forEach(b=>b.classList.toggle('current',b.dataset.example===id));updateCount();renderSources();$('#result-subtitle').textContent='案例已载入，点击左侧按钮开始核验';}
function resetSources(){state.sources=structuredClone(state.config.sources).map(s=>({...s,selected:true}));renderSources();}
function modeHelp(){const live=$('#mode').value==='live';$('#mode-help').textContent=live?(state.config?.liveReady?'使用当前观点与所选可用材料实时调用模型。':'尚未配置模型服务；点击核验会显示连接提示。'):'仅展示原题三例的人工参考结果，不代表模型运行。';$('#run-label').textContent=live?'开始 AI 核验':'查看参考核验';}
async function loadConfig(first=false){
 const response=await fetch('/api/config');if(!response.ok)throw new Error('暂时无法读取连接配置，请刷新页面。');state.config=await response.json();state.examples=state.config.examples;
 if(first){resetSources();$('#mode').value=state.config.liveReady?'live':'reference';loadExample('A');}
 $('#connection-label').textContent=state.config.liveReady?'模型已连接 · 可实时核验':'参考演示 · 模型待连接';$('#connection').classList.toggle('ready',state.config.liveReady);
 $('#settings-status').innerHTML=`<div class="settings-status">${state.config.liveReady?`已配置模型：${escape(state.config.model)}<br>实际可用性以一次核验成功为准。`:'尚未配置模型服务。<br>当前可查看原题三例的人工参考结果。'}</div>`;modeHelp();
}
function renderResult(){
 const r=state.result;if(!r)return;
 const counts={supported:0,contradicted:0,insufficient:0,conditional:0};r.claims.forEach(c=>counts[c.status]++);
 const reviewed=Object.values(state.reviews).filter(x=>x.checked).length;
 const shown=r.claims.filter(c=>state.filter==='all'||c.status===state.filter);
 $('#result-subtitle').textContent=`${r.claims.length} 项陈述 · ${reviewed} 项已人工复核`;
 $('#result').innerHTML=`
 <div class="panel summary-panel"><div class="run-meta"><span class="mode-tag">${r.provenance.mode==='live'?'真实模型运行':'参考结果演示'}</span><span>截至 ${escape(r.input.asOf)}</span><span>· ${r.input.sources.length-r.provenance.excludedSources.length} 份可用材料</span></div><h3>${escape(r.summary)}</h3><p class="summary-disclosure">${r.provenance.mode==='reference'?'本结果为人工编制的原题参考答案，非本次模型生成。':'模型判断供研究员复核；原文引用已由程序检查。'}${r.provenance.excludedSources.length?` 已排除晚于查询时点的材料：${r.provenance.excludedSources.join('、')}。`:''}</p></div>
 ${r.warnings.length?`<div class="notice">${r.warnings.map(escape).join('<br>')}</div>`:''}
 ${r.answer?`<div class="panel answer-panel"><h3>${r.answerNeedsReview?'查询回答 · 引用异常，需人工复核':'查询回答'}</h3><p>${escape(r.answer)}</p></div>`:''}
 <div class="stat-row"><div class="stat green"><strong>${counts.supported.toString().padStart(2,'0')}</strong><span>有证据支持</span></div><div class="stat red"><strong>${counts.contradicted.toString().padStart(2,'0')}</strong><span>与材料不符</span></div><div class="stat amber"><strong>${(counts.insufficient+counts.conditional).toString().padStart(2,'0')}</strong><span>证据不足 / 推断需限定</span></div></div>
 <div class="claim-toolbar"><h3>逐项核验 <span class="count">${r.claims.length}</span></h3><label><span class="sr-only">筛选核验状态</span><select id="claim-filter"><option value="all">全部陈述</option>${Object.entries(statusNames).map(([k,v])=>`<option value="${k}" ${state.filter===k?'selected':''}>${v}</option>`).join('')}</select></label></div>
 <div id="claims">${shown.length?shown.map(c=>claimHtml(c)).join(''):'<div class="panel" style="padding:30px;color:var(--muted)">当前筛选下没有陈述。</div>'}</div>
 ${r.rewrite?`<details class="panel rewrite-panel"><summary>查看建议改写 · 采用前请人工确认</summary><p>${escape(r.rewrite)}</p></details>`:''}
 <div class="run-footnote">运行时间 ${new Date(r.provenance.createdAt).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false})}（北京时间）<br>${r.provenance.mode==='live'?`模型 ${escape(r.provenance.model)} · 用时 ${(r.provenance.elapsedMs/1000).toFixed(1)} 秒 · `:'人工参考 · '}记录 ${escape(r.provenance.runId.slice(0,8))} · 输入指纹 ${r.provenance.inputHash.slice(0,12)}</div>`;
 $('#export').disabled=false;setBusy(false);
}
function claimHtml(c){const rev=state.reviews[c.id]||{};return `<article class="panel claim-card" data-claim="${c.id}"><div class="claim-top"><span class="claim-no">${c.id.replace('C','').padStart(2,'0')} / ${escape(c.issue)}</span><span class="badge ${c.status}">${icon(statusIcons[c.status])}${statusNames[c.status]}</span></div><h4>${escape(c.text)}</h4><p class="claim-reason">${escape(c.reason)}</p>${c.suggestion?`<div class="suggestion"><span>修改建议</span>${escape(c.suggestion)}</div>`:''}<div class="claim-bottom"><div class="evidence-pills">${[...new Set(c.evidence.map(e=>e.sourceId))].map(id=>`<button class="evidence-pill" data-evidence-source="${escape(id)}" data-claim-id="${c.id}">${icon('link')}${escape(id)} 查看原文</button>`).join('')||'<span class="claim-no">未找到足够证据</span>'}</div><button class="review-btn ${rev.checked?'checked':''}" data-review="${c.id}" aria-pressed="${!!rev.checked}">${icon(rev.checked?'check':'circle')}${rev.checked?'已人工复核':'标记已复核'}</button></div><label class="sr-only" for="note-${c.id}">${c.id}复核备注</label><textarea id="note-${c.id}" class="review-note ${rev.checked||rev.note?'':'hidden'}" data-note="${c.id}" placeholder="记录研究员的判断、补充证据或保留意见…">${escape(rev.note||'')}</textarea></article>`;}
async function run(){
 if(state.controller)return;
 invalidate();const epoch=state.epoch;const controller=new AbortController();state.controller=controller;setBusy(true);const started=Date.now();
 const ticker=setInterval(()=>{$('#loading-time').textContent=$('#mode').value==='live'?`正在等待模型结果 · 已等待 ${Math.floor((Date.now()-started)/1000)} 秒`:'正在载入原题参考结果…';},1000);
 try{
  const input={task:state.task,text:$('#viewpoint').value,asOf:$('#asof').value,sources:state.sources.filter(s=>s.selected).map(({selected,kind,...s})=>s),mode:$('#mode').value};
  const response=await fetch('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json',...($('#access-code').value?{Authorization:`Bearer ${$('#access-code').value}`}:{})},body:JSON.stringify(input),signal:controller.signal});
  const data=await response.json();if(epoch!==state.epoch)return;
  if(!response.ok)throw new Error(data.error||'核验失败，请重试。');state.result=data;renderResult();
 }catch(e){if(epoch===state.epoch&&e.name!=='AbortError')notice(e.message||'请求失败，请检查服务连接。');}
 finally{clearInterval(ticker);if(epoch===state.epoch){state.controller=null;setBusy(false);}}
}
function openSource(id,claimId){
 const source=state.sources.find(s=>s.id===id);if(!source){toast('该引用未匹配到可用材料，请人工复核。');return;}
 state.editing=id;$('#source-id').textContent=`SOURCE ${id}`;$('#source-title').value=source.title;$('#source-publisher').value=source.publisher;$('#source-date').value=source.publishedAt;$('#source-period').value=source.period;$('#source-text').value=source.text;show($('#delete-source'),true);
 const claim=state.result?.claims.find(c=>c.id===claimId);
 $('#source-quotes').innerHTML=claim?claim.evidence.filter(e=>e.sourceId===id).map(e=>`<blockquote class="quote-box"><small>${e.verified?'引用已匹配原文':'引用未通过原文匹配'} · ${e.relation==='support'?'支持':e.relation==='oppose'?'反驳 / 限制':'上下文'}</small>${escape(e.quote)}</blockquote>`).join(''):'';
 $('#source-dialog').showModal();
}
function exportRecord(format){
 if(!state.result)return;
 const record={...state.result,researcherReviews:state.reviews,exportedAt:new Date().toISOString(),disclaimer:'考试材料均为虚构。原文匹配不能替代语义审核；参考模式为人工编制，不代表模型运行。'};
 const content=format==='json'?JSON.stringify(record,null,2):reportHtml(record);
 const blob=new Blob([content],{type:format==='json'?'application/json;charset=utf-8':'text/html;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download=`核验记录-${record.provenance.mode}-${record.input.task}-${record.provenance.runId.slice(0,8)}.${format}`;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);$('#export-dialog').close();toast('核验记录已导出');
}
function reportHtml(r){return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>证研 · 核验记录</title><style>body{max-width:900px;margin:40px auto;padding:0 24px;font:15px/1.9 system-ui;color:#263f30}h1{font-size:28px}h2{font-size:20px;margin-top:32px}article{border:1px solid #dae2d3;padding:20px;margin:16px 0;border-radius:5px}blockquote{background:#f0f5eb;padding:15px;border-left:3px solid #96af85;margin:12px 0}small{color:#708267}pre{white-space:pre-wrap;word-break:break-word;font:inherit}.meta{background:#f0f5eb;padding:18px}footer{font-size:12px;color:#7c8a70;margin-top:40px}@media print{article{break-inside:avoid}}</style></head><body><small>EVIDENCE DESK / 证研</small><h1>投研观点证据核验记录</h1><div class="meta"><b>${escape(r.provenance.label)}</b><br>查询时点：${escape(r.input.asOf)}<br>运行时间：${escape(r.provenance.createdAt)}<br>模型：${escape(r.provenance.model||'无（人工参考）')}<br>运行ID：${escape(r.provenance.runId)}<br>输入指纹：${escape(r.provenance.inputHash)}</div><h2>输入</h2><p>${escape(r.input.text)}</p><h2>总体判断</h2><p>${escape(r.summary)}</p>${r.answer?`<h2>查询回答${r.answerNeedsReview?'（引用异常，需复核）':''}</h2><p>${escape(r.answer)}</p>`:''}${r.warnings.length?`<p>${r.warnings.map(escape).join('<br>')}</p>`:''}<h2>逐项核验</h2>${r.claims.map(c=>`<article><b>${c.id} · ${statusNames[c.status]} · ${escape(c.issue)}</b><h3>${escape(c.text)}</h3><p>${escape(c.reason)}</p><p>修改建议：${escape(c.suggestion)}</p>${c.evidence.map(e=>`<blockquote><small>${escape(e.sourceId)} · ${e.verified?'原文匹配通过':'原文匹配未通过'}</small><br>${escape(e.quote)}</blockquote>`).join('')}<p>人工复核：${r.researcherReviews[c.id]?.checked?'已复核':'未复核'}</p><p>${escape(r.researcherReviews[c.id]?.note||'')}</p></article>`).join('')}${r.rewrite?`<h2>建议改写</h2><p>${escape(r.rewrite)}</p>`:''}<h2>输入材料快照</h2>${r.input.sources.map(s=>`<article><b>${escape(s.id)} · ${escape(s.title)}</b><p>来源：${escape(s.publisher)}<br>发布：${escape(s.publishedAt)}<br>统计期：${escape(s.period)}${r.provenance.excludedSources.includes(s.id)?'<br>本次已排除：发布日期晚于查询时点':''}</p><pre>${escape(s.text)}</pre></article>`).join('')}<footer>${escape(r.disclaimer)}</footer></body></html>`;}
paintIcons();
document.addEventListener('click',e=>{
 const example=e.target.closest('[data-example]');if(example)loadExample(example.dataset.example);
 const src=e.target.closest('[data-open-source]');if(src)openSource(src.dataset.openSource);
 const ref=e.target.closest('[data-evidence-source]');if(ref)openSource(ref.dataset.evidenceSource,ref.dataset.claimId);
 const rev=e.target.closest('[data-review]');if(rev){const id=rev.dataset.review;state.reviews[id]={...state.reviews[id],checked:!state.reviews[id]?.checked};renderResult();}
 if(e.target.closest('.close-dialog'))e.target.closest('dialog').close();
});
document.addEventListener('change',e=>{
 if(e.target.matches('[data-select-source]')){const s=state.sources.find(s=>s.id===e.target.dataset.selectSource);s.selected=e.target.checked;invalidate();renderSources();}
 if(e.target.id==='claim-filter'){state.filter=e.target.value;renderResult();}
});
document.addEventListener('input',e=>{if(e.target.matches('[data-note]')){const id=e.target.dataset.note;state.reviews[id]={...state.reviews[id],note:e.target.value};}});
$('#viewpoint').addEventListener('input',()=>{invalidate();state.example=null;document.querySelectorAll('[data-example]').forEach(b=>b.classList.remove('current'));updateCount();});
$('#asof').addEventListener('change',()=>{invalidate();renderSources();});
$('#mode').addEventListener('change',()=>{invalidate();modeHelp();});
$('#tab-verify').addEventListener('click',()=>{if(state.task!=='verify'){invalidate();setTask('verify');}});
$('#tab-query').addEventListener('click',()=>{if(state.task!=='query'){invalidate();setTask('query');}});
$('#run').addEventListener('click',run);$('#cancel').addEventListener('click',()=>{invalidate();notice('已停止等待。模型服务可能仍在处理刚才的请求。');});
$('#reset-sources').addEventListener('click',()=>{invalidate();resetSources();toast('已恢复六份原题材料');});
$('#add-source').addEventListener('click',()=>{if(state.sources.length>=20){toast('最多支持20份材料');return;}state.editing=null;$('#source-form').reset();$('#source-id').textContent='NEW SOURCE';$('#source-date').value=$('#asof').value;$('#source-period').value='未注明';$('#source-quotes').replaceChildren();show($('#delete-source'),false);$('#source-dialog').showModal();});
$('#source-form').addEventListener('submit',e=>{e.preventDefault();const title=$('#source-title').value.trim(),publisher=$('#source-publisher').value.trim(),text=$('#source-text').value.trim();if(!title||!publisher||!text){toast('请补全材料标题、来源和正文');return;}const updated={title,publisher,text,publishedAt:$('#source-date').value,period:$('#source-period').value.trim()||'未注明'};const old=state.sources.find(s=>s.id===state.editing);if(old){if(Object.keys(updated).some(k=>old[k]!==updated[k])){invalidate();Object.assign(old,updated,{kind:'已编辑'});}}else{invalidate();const id=`S${Math.max(0,...state.sources.map(s=>Number(s.id.slice(1))))+1}`;state.sources.push({...updated,id,selected:true,kind:'自定义'});}renderSources();$('#source-dialog').close();});
$('#delete-source').addEventListener('click',()=>{invalidate();state.sources=state.sources.filter(s=>s.id!==state.editing);renderSources();$('#source-dialog').close();});
$('#connection').addEventListener('click',()=>$('#settings-dialog').showModal());$('#open-settings').addEventListener('click',()=>$('#settings-dialog').showModal());
$('#refresh-config').addEventListener('click',async()=>{try{await loadConfig();toast('连接配置已更新');}catch(e){toast(e.message);}});
$('#export').addEventListener('click',()=>$('#export-dialog').showModal());$('#export-html').addEventListener('click',()=>exportRecord('html'));$('#export-json').addEventListener('click',()=>exportRecord('json'));
$('#nav-work').addEventListener('click',()=>{window.scrollTo({top:0,behavior:'smooth'});$('#viewpoint').focus();});
loadConfig(true).catch(e=>{notice(e.message);$('#connection-label').textContent='服务连接失败';$('#run').disabled=true;});
