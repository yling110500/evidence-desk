import {nextSourceId} from '../../src/workspace.mjs';
import {prepareSource} from './files.mjs';
export async function saveDocument({getWorkspace,setWorkspace,storage,sessionId,parsed,metadata,text,editing=null}){
 if(!metadata.title||!text)throw new Error('请补充标题与实际正文。');
 let d;
 if(parsed){if(!storage)throw new Error('本机资料库未打开，暂不能保存原文件。');d=prepareSource(parsed,metadata,{excerpt:text===parsed.text?undefined:text});d.fileId=crypto.randomUUID();await storage.putFile(d.fileId,parsed.original);}
 else{if(editing?.fullText&&!editing.fullText.includes(text))throw new Error('选段须来自原始提取正文。若要添加其他内容，请新增手动资料。');d={...editing,...metadata,text,origin:editing?.origin||'manual',segments:editing?.segments||[{text,paragraph:1}],revision:(editing?.revision||0)+1};}
 const w=structuredClone(getWorkspace());
 if(editing?.id&&!w.documents.some(x=>x.id===editing.id))throw new Error('这份资料已被移除，请重新添加。');
 d.id=editing?.id||nextSourceId(w);w.sourceCounter=Math.max(w.sourceCounter||6,Number(d.id.slice(1)));
 const index=w.documents.findIndex(x=>x.id===d.id);if(index>=0)w.documents[index]=d;else w.documents.push(d);
 const s=w.sessions.find(s=>s.id===sessionId);if(s&&!s.selectedSourceIds.includes(d.id)&&s.selectedSourceIds.length<20)s.selectedSourceIds.push(d.id);
 setWorkspace(w);return d;
}
