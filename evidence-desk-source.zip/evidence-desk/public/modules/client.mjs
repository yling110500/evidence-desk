import {createPagesTransport} from '../../src/pages-client.mjs';
export function createClient({apiBase='',accessCode=()=>'',transport=fetch,staticMode=false,configTimeoutMs=8000,pollIntervalMs=1500,jobTimeoutMs=190000}={}){
 const base=apiBase.replace(/\/$/,'');const request=staticMode?createPagesTransport(base,transport):(path,options)=>transport(`${base}/api/${path}`,options);
 async function call(path,body,signal){
  const config=path==='config';if(config&&!signal)signal=AbortSignal.timeout(configTimeoutMs);
  if(body){const project=d=>Object.fromEntries(['id','title','publisher','publishedAt','period','text','origin'].filter(k=>d[k]!==undefined).map(k=>[k,d[k]]));body={...body,...(body.sources?{sources:body.sources.map(project)}:{}),...(body.documents?{documents:body.documents.map(project)}:{})};}
  const deadline=Date.now()+jobTimeoutMs;let next=path,jobId=null;
  while(true){
   signal?.throwIfAborted();const code=accessCode();let r;
   try{r=await request(next,{method:body?'POST':'GET',headers:{...(body?{'Content-Type':'application/json'}:{}),...(code?{Authorization:`Bearer ${code}`}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:config?signal:AbortSignal.any([...(signal?[signal]:[]),AbortSignal.timeout(25000)])});}
   catch(e){if(e.name==='AbortError')throw e;if(e.name==='TimeoutError')throw new Error(config?'连接检查超时，可在设置中重试。':'服务响应超时，请稍后重试。');throw new Error('无法连接服务，请检查后端或网络。');}
   let data;try{data=await r.json();}catch{throw new Error('服务未返回有效响应。');}
   if(!r.ok)throw new Error(data.error||'请求失败，请重试。');
   if(r.status!==202)return data;
   if(!/^[a-f0-9-]{36}$/.test(data.jobId||'')||(jobId&&jobId!==data.jobId))throw new Error('服务返回的任务编号无效，请重试。');
   if(Date.now()>=deadline)throw new Error('核验等待超时，请稍后重试。');
   jobId=data.jobId;next=`jobs/${jobId}`;body=undefined;
   await new Promise((resolve,reject)=>{const done=()=>{signal?.removeEventListener('abort',abort);resolve();};const abort=()=>{clearTimeout(timer);reject(signal.reason);};const timer=setTimeout(done,pollIntervalMs);if(signal?.aborted)abort();else signal?.addEventListener('abort',abort,{once:true});});
  }
 }
 return {config:()=>call('config'),chat:(b,s)=>call('chat',b,s),search:(b,s)=>call('search',b,s),fetchPage:(b,s)=>call('fetch',b,s),versions:(b,s)=>call('versions',b,s),analyze:(b,s)=>call('analyze',b,s)};
}
