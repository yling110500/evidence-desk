// Fragments are not sent to the hosting server or in HTTP referrers.
// Accept the separate demo credential only, never a model API key.
export function readDemoCode(hash){
 if(typeof hash!=='string'||hash.length>64)return '';
 return /^#demo=(ED-[a-f0-9]{10})$/i.exec(hash)?.[1]||'';
}
