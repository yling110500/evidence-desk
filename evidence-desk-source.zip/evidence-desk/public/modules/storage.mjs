import {serializeBackup,validateBackup} from '../../src/workspace.mjs';
export async function openStorage({factory=globalThis.indexedDB,name='evidence-desk-v2'}={}){
 if(!factory)throw new Error('浏览器不支持本机保存。');
 const db=await new Promise((resolve,reject)=>{const r=factory.open(name,1);r.onupgradeneeded=()=>{r.result.createObjectStore('workspace');r.result.createObjectStore('files');};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(new Error('无法打开本机资料库。'));});
 const tx=(stores,mode,action)=>new Promise((resolve,reject)=>{let value;const t=db.transaction(stores,mode);t.oncomplete=()=>resolve(value);t.onerror=t.onabort=()=>reject(new Error('本机保存失败，请导出备份后检查浏览器空间。'));try{value=action(t);}catch(e){t.abort();reject(e);}});
 const get=(store,key)=>new Promise((resolve,reject)=>{const r=db.transaction(store).objectStore(store).get(key);r.onsuccess=()=>resolve(r.result??null);r.onerror=()=>reject(new Error('读取本机资料失败。'));});
 return {
  load:()=>get('workspace','current'),
  save:w=>tx(['workspace'],'readwrite',t=>t.objectStore('workspace').put(w,'current')),
  putFile:(id,blob)=>tx(['files'],'readwrite',t=>t.objectStore('files').put(blob,id)),
  getFile:id=>get('files',id),
  async exportBackup(){const w=await get('workspace','current');if(!w)throw new Error('还没有可导出的资料。');const rows=await new Promise((resolve,reject)=>{const data=[],r=db.transaction('files').objectStore('files').openCursor();r.onsuccess=()=>{const c=r.result;if(c){data.push({id:c.key,blob:c.value});c.continue();}else resolve(data);};r.onerror=()=>reject(new Error('附件读取失败。'));});const files=await Promise.all(rows.map(async f=>{const bytes=new Uint8Array(await f.blob.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));return {id:f.id,type:f.blob.type,data:btoa(binary)};}));return serializeBackup(w,files);},
  async importBackup(raw){const backup=validateBackup(raw);const rows=backup.files.map(f=>({id:f.id,blob:new Blob([Uint8Array.from(atob(f.data),c=>c.charCodeAt(0))],{type:f.type||'application/octet-stream'})}));await tx(['workspace','files'],'readwrite',t=>{t.objectStore('workspace').put(backup.workspace,'current');t.objectStore('files').clear();for(const f of rows)t.objectStore('files').put(f.blob,f.id);});return backup.workspace;}
 };
}
