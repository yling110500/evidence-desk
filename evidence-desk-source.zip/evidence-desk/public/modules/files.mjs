export async function parseFile(file,{purpose='evidence'}={}){
 if(file.size>10*1024*1024)throw new Error('单个文件不能超过10MB。');
 const ext=file.name.split('.').at(-1).toLowerCase();let text='',segments=[],warnings=[];
 try{
  if(['txt','md','markdown'].includes(ext)){text=new TextDecoder('utf-8',{fatal:true}).decode(await file.arrayBuffer());segments=text.split(/\n\s*\n/).filter(x=>x.trim()).map((text,i)=>({text,paragraph:i+1}));}
  else if(ext==='docx'){const {default:mammoth}=await import('mammoth/mammoth.browser.js');const r=await mammoth.extractRawText({arrayBuffer:await file.arrayBuffer()});text=r.value;warnings=r.messages.map(m=>m.message);segments=text.split(/\n\s*\n/).filter(x=>x.trim()).map((text,i)=>({text,paragraph:i+1}));}
  else if(ext==='pdf'){
   const pdfjs=await import('pdfjs-dist/legacy/build/pdf.mjs');
   if(typeof window!=='undefined')pdfjs.GlobalWorkerOptions.workerSrc=new URL('./pdf.worker.min.mjs',document.baseURI).href;
   const task=pdfjs.getDocument({data:new Uint8Array(await file.arrayBuffer()),isEvalSupported:false,useSystemFonts:true});
   let pdf;try{pdf=await task.promise;if(pdf.numPages>300)throw new Error('页数超过300页，请拆分后上传。');for(let page=1;page<=pdf.numPages;page++){const p=await pdf.getPage(page),content=await p.getTextContent();const body=content.items.map(x=>x.str+(x.hasEOL?'\n':' ')).join('').trim();segments.push({text:body,page});}text=segments.map(s=>s.text).join('\n\n');}finally{await task.destroy();}
  }else throw new Error('支持TXT、Markdown、文字型PDF和DOCX文件。');
 }catch(e){if(/支持|页数/.test(e.message))throw e;throw new Error(ext==='pdf'?'PDF无法提取正文，可能为扫描、加密或损坏文件；首版暂不支持OCR。':ext==='docx'?'Word文件无法解析，请确认是有效DOCX。':'文本编码无法识别，请转换为UTF-8后上传。');}
 text=text.trim();if(!text)throw new Error('没有提取到正文，扫描件请先转为可复制文字。');if(text.length>2000000)throw new Error('提取正文超过处理上限，请拆分文件。');
 if(purpose==='opinion'&&text.length>8000)throw new Error('观点超过8000字，请缩短或选择需要核验的段落。');
 if(text.length>16000)warnings.push('全文超过单份核验上限16000字，请明确选择用于核验的段落。');
 return {name:file.name,mime:file.type,text,segments,warnings,original:file};
}
export function prepareSource(parsed,metadata,{excerpt}={}){
 const text=excerpt??parsed.text;if(!text.trim()||text.length>16000)throw new Error('用于核验的正文须为1—16000字，请选择明确选段。');
 if(excerpt&&!parsed.text.includes(excerpt))throw new Error('选段必须来自实际提取的原文。');
 return {...metadata,text,fullText:parsed.text,segments:parsed.segments,excerpt:excerpt?{text:excerpt}:null,origin:'upload',revision:1,importedAt:new Date().toISOString(),originalName:parsed.name};
}
