import { Inject, Injectable } from '@nestjs/common';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import type { Cache } from 'cache-manager';
import type { EvidenceHttpInput } from '../../../shared/api.interface';
import { createEvidenceRequest } from './evidence-request';
import { handleApi } from './evidence-core.cjs';
import { EvidenceJobs } from './evidence-jobs';

@Injectable()
export class EvidenceService {
  private readonly jobs: EvidenceJobs;
  constructor(@Inject(CACHE_MANAGER) cache: Cache) { this.jobs = new EvidenceJobs(cache); }
  async execute(input: EvidenceHttpInput): Promise<Response> {
    const request = createEvidenceRequest(input);
    // Reuse the core's origin and preflight policy before touching the shared job store.
    const preflight = await handleApi(new Request(request.url, { method: 'OPTIONS', headers: request.headers }), process.env);
    if (preflight.status !== 204 || request.method === 'OPTIONS') return preflight;
    const isPoll = input.endpoint.startsWith('jobs/');
    const isPaid = ['chat', 'search', 'fetch', 'versions'].includes(input.endpoint) ||
      (input.endpoint === 'analyze' && (input.body as { mode?: string } | undefined)?.mode === 'live');
    if (!isPoll && (!isPaid || request.method !== 'POST')) return handleApi(request, process.env);
    let result: Response;
    if (process.env.DEMO_ACCESS_CODE && request.headers.get('authorization') !== `Bearer ${process.env.DEMO_ACCESS_CODE}`) {
      result = Response.json({ error: '体验码不正确，请在连接设置中填写。' }, { status: 401 });
    } else if (isPoll) {
      const id = input.endpoint.slice(5);
      result = request.method !== 'GET' ? Response.json({ error: '请使用GET请求。' }, { status: 405 }) :
        /^[a-f0-9-]{36}$/.test(id) ? await this.jobs.poll(id) : Response.json({ error: '任务编号无效。' }, { status: 404 });
    } else {
      try { result = await this.jobs.submit(() => handleApi(request, process.env)); }
      catch { result = Response.json({ error: '任务存储暂不可用，请稍后重试。' }, { status: 503 }); }
    }
    for (const name of ['Access-Control-Allow-Origin', 'Vary']) {
      const value = preflight.headers.get(name); if (value) result.headers.set(name, value);
    }
    result.headers.set('Cache-Control', 'no-store');
    result.headers.set('X-Content-Type-Options', 'nosniff');
    return result;
  }
}
