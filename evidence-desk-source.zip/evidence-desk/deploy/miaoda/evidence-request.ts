import type { EvidenceHttpInput } from '../../../shared/api.interface.ts';

export function createEvidenceRequest(input: EvidenceHttpInput): Request {
  const headers: Headers = new Headers();
  for (const [key, value] of Object.entries(input.headers)) {
    if (value !== undefined) headers.set(key, Array.isArray(value) ? value.join(', ') : value);
  }
  const hasBody: boolean = !['GET', 'HEAD', 'OPTIONS'].includes(input.method);
  return new Request(`${input.protocol}://${input.host}/api/${input.endpoint}`, {
    method: input.method,
    headers,
    ...(hasBody ? { body: JSON.stringify(input.body ?? null) } : {}),
  });
}
