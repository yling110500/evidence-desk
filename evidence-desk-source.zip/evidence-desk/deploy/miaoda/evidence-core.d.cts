export function handleApi(request: Request, env?: Record<string, string | undefined>): Promise<Response>;
