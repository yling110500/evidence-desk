妙搭后端适配层：复用src/api.mjs全部核验逻辑，不另写模型业务。

将这些文件放入新应用server/modules/evidence，补充shared/api.interface.ts中的EvidenceHttpInput（method/protocol/host/endpoint/headers/body）。
用esbuild将src/api.mjs打包为Node22 CJS的evidence-core.cjs；构建时作为Nest assets复制modules/evidence/*.cjs至dist/server。
注册EvidenceModule于ViewModule之前。匿名业务接口只使用Bearer体验码和Origin白名单，不用Cookie身份；CSRF保留在/api/__platform__/*。
模型API密钥等六个变量只通过平台online环境配置；源码与压缩包不含值。
平台官方构建CLI为@lark-apaas/fullstack-cli（不要误装同名公共包fullstack-cli）。
已有源码无需数据迁移；知识库及会话仍保存于原GitHub域名下的浏览器。

长请求：EvidenceService注入平台CACHE_MANAGER，POST付费业务返回202和随机任务ID，GET /api/jobs/:jobId取回结果；跨实例共享缓存，10分钟失效，处理超过3分钟明确超时。提交与轮询均检查体验码和Origin。缓存写入后回读，存储异常不假报成功。客户端只提交一次，之后轮询；取消等待不保证取消上游计费。
依赖：@nestjs/cache-manager、cache-manager（平台模板已声明），PlatformModule默认挂载缓存模块；无需新增数据库或登录流程。
