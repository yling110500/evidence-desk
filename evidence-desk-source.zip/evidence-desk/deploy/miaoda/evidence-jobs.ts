interface JobCache {
  get<T>(key: string): Promise<T | undefined | null>;
  set(key: string, value: unknown, ttl: number): Promise<unknown>;
}
interface Job {
  jobId: string;
  createdAt: number;
  result?: { status: number; body: string };
}
const ttl = 600_000;
export class EvidenceJobs {
  constructor(private readonly cache: JobCache, private readonly now: () => number = Date.now) {}
  private key(id: string): string { return `evidence-job:${id}`; }
  private async save(job: Job): Promise<void> {
    await this.cache.set(this.key(job.jobId), job, ttl);
    const stored = await this.cache.get<Job>(this.key(job.jobId));
    if (!stored || (!!job.result && !stored.result)) throw new Error('任务存储暂不可用，请稍后重试。');
  }
  async submit(run: () => Promise<Response>): Promise<Response> {
    const job: Job = { jobId: crypto.randomUUID(), createdAt: this.now() };
    await this.save(job);
    void this.complete(job, run);
    return Response.json({ jobId: job.jobId, status: 'pending' }, { status: 202 });
  }
  private async complete(job: Job, run: () => Promise<Response>): Promise<void> {
    try {
      let response: Response;
      try { response = await run(); }
      catch { response = Response.json({ error: '核验任务处理失败，请重试。' }, { status: 500 }); }
      await this.save({ ...job, result: { status: response.status, body: await response.text() } });
    } catch {
      // A lost result times out explicitly; never substitute a sample answer.
    }
  }
  async poll(id: string): Promise<Response> {
    const job = await this.cache.get<Job>(this.key(id));
    if (!job) return Response.json({ error: '任务已过期或服务暂不可用，请重新提交。' }, { status: 404 });
    if (job.result) return new Response(job.result.body, { status: job.result.status, headers: { 'Content-Type': 'application/json' } });
    if (this.now() - job.createdAt > 180_000) return Response.json({ error: '核验任务超时，请缩短输入后重试。' }, { status: 504 });
    return Response.json({ jobId: id, status: 'pending' }, { status: 202 });
  }
}
