import { All, Controller, Inject, Req, Res } from '@nestjs/common';
import type { Request, Response } from 'express';
import { EvidenceService } from './evidence.service';

@Controller('api')
export class EvidenceController {
  constructor(@Inject(EvidenceService) private readonly evidence: EvidenceService) {}

  @All(['config', 'chat', 'analyze', 'search', 'fetch', 'versions', 'jobs/:jobId'])
  async execute(@Req() request: Request, @Res() response: Response): Promise<void> {
    const result: globalThis.Response = await this.evidence.execute({
      method: request.method,
      protocol: request.protocol,
      host: request.get('host') ?? 'localhost',
      endpoint: request.params.jobId ? `jobs/${request.params.jobId}` : request.path.split('/').at(-1) ?? '',
      headers: request.headers,
      body: request.body as unknown,
    });
    result.headers.forEach((value: string, key: string) => response.setHeader(key, value));
    response.status(result.status).send(Buffer.from(await result.arrayBuffer()));
  }
}
